﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Field1 = New Court.Field()
        Me.Court11 = New Court.Court1()
        Me.Gym1 = New Court.Gym()
        Me.SuspendLayout()
        '
        'Field1
        '
        Me.Field1.BackColor = System.Drawing.Color.White
        Me.Field1.Location = New System.Drawing.Point(-3, -1)
        Me.Field1.Name = "Field1"
        Me.Field1.Size = New System.Drawing.Size(845, 674)
        Me.Field1.TabIndex = 2
        '
        'Court11
        '
        Me.Court11.BackColor = System.Drawing.Color.White
        Me.Court11.Location = New System.Drawing.Point(-3, -1)
        Me.Court11.Name = "Court11"
        Me.Court11.Size = New System.Drawing.Size(845, 674)
        Me.Court11.TabIndex = 1
        '
        'Gym1
        '
        Me.Gym1.BackColor = System.Drawing.Color.White
        Me.Gym1.Location = New System.Drawing.Point(-3, -1)
        Me.Gym1.Name = "Gym1"
        Me.Gym1.Size = New System.Drawing.Size(853, 678)
        Me.Gym1.TabIndex = 0
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(850, 681)
        Me.Controls.Add(Me.Gym1)
        Me.Controls.Add(Me.Field1)
        Me.Controls.Add(Me.Court11)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form4"
        Me.Text = "Form4"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Gym2 As Gym
    Friend WithEvents Gym1 As Gym
    Friend WithEvents Court11 As Court1
    Friend WithEvents Field1 As Field
End Class
