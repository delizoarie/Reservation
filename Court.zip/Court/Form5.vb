﻿Public Class Form5
    Private Sub TableBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) 
        Me.Validate()
        Me.TableBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database2DataSet)

    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database2DataSet.Table' table. You can move, or remove it, as needed.
        Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)









    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Close()
    End Sub

    Private Sub TableDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = DateTime.Now
        Dim timeStart As String
        Dim timeEnd As String
        For i As Integer = 0 To Me.TableTableAdapter.CountRows()
            Try
                timeStart = Me.TableDataGridView(5, i).Value.ToString
                timeEnd = Me.TableDataGridView(6, i).Value.ToString
            Catch ex As Exception

            End Try
            Label6.Text = timeStart
            Label7.Text = timeEnd
            If timeStart.Contains(Label1.Text) Then
                MessageBox.Show("Reservation of" & Me.TableDataGridView(0, i).Value.ToString & "Start")

            End If

            If timeEnd.Contains(Label1.Text) Then
                MessageBox.Show("Reservation of" & Me.TableDataGridView(0, i).Value.ToString & "End")

            End If
        Next
    End Sub
End Class