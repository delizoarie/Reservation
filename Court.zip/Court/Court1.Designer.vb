﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Court1
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Label3 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Reserved_byLabel As System.Windows.Forms.Label
        Dim OrganizerLabel As System.Windows.Forms.Label
        Dim Ending_TimeLabel As System.Windows.Forms.Label
        Dim Starting_TimeLabel As System.Windows.Forms.Label
        Dim Estimated_No__of_ParticipantsLabel As System.Windows.Forms.Label
        Dim Date_of_UseLabel As System.Windows.Forms.Label
        Dim Date_ReservedLabel As System.Windows.Forms.Label
        Dim XU_ID_Label As System.Windows.Forms.Label
        Dim Contact_Label As System.Windows.Forms.Label
        Dim NameLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Court1))
        Me.Button3 = New System.Windows.Forms.Button()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Reserved_byTextBox = New System.Windows.Forms.TextBox()
        Me.TableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database2DataSet = New Court.Database2DataSet()
        Me.OrganizerTextBox = New System.Windows.Forms.TextBox()
        Me.Ending_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Starting_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Estimated_No__of_ParticipantsTextBox = New System.Windows.Forms.TextBox()
        Me.Date_of_UseDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Date_ReservedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.TableTableAdapter = New Court.Database2DataSetTableAdapters.TableTableAdapter()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TableAdapterManager = New Court.Database2DataSetTableAdapters.TableAdapterManager()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.XU_ID_TextBox = New System.Windows.Forms.TextBox()
        Me.Contact_TextBox = New System.Windows.Forms.TextBox()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Label3 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Reserved_byLabel = New System.Windows.Forms.Label()
        OrganizerLabel = New System.Windows.Forms.Label()
        Ending_TimeLabel = New System.Windows.Forms.Label()
        Starting_TimeLabel = New System.Windows.Forms.Label()
        Estimated_No__of_ParticipantsLabel = New System.Windows.Forms.Label()
        Date_of_UseLabel = New System.Windows.Forms.Label()
        Date_ReservedLabel = New System.Windows.Forms.Label()
        XU_ID_Label = New System.Windows.Forms.Label()
        Contact_Label = New System.Windows.Forms.Label()
        NameLabel = New System.Windows.Forms.Label()
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(400, 371)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(190, 17)
        Label3.TabIndex = 70
        Label3.Text = "Manpower and Other Needs:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(47, 371)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(84, 17)
        Label2.TabIndex = 69
        Label2.Text = "Facility Use:"
        '
        'Reserved_byLabel
        '
        Reserved_byLabel.AutoSize = True
        Reserved_byLabel.Location = New System.Drawing.Point(44, 317)
        Reserved_byLabel.Name = "Reserved_byLabel"
        Reserved_byLabel.Size = New System.Drawing.Size(92, 17)
        Reserved_byLabel.TabIndex = 65
        Reserved_byLabel.Text = "Reserved by:"
        '
        'OrganizerLabel
        '
        OrganizerLabel.AutoSize = True
        OrganizerLabel.Location = New System.Drawing.Point(61, 269)
        OrganizerLabel.Name = "OrganizerLabel"
        OrganizerLabel.Size = New System.Drawing.Size(75, 17)
        OrganizerLabel.TabIndex = 63
        OrganizerLabel.Text = "Organizer:"
        '
        'Ending_TimeLabel
        '
        Ending_TimeLabel.AutoSize = True
        Ending_TimeLabel.Location = New System.Drawing.Point(499, 316)
        Ending_TimeLabel.Name = "Ending_TimeLabel"
        Ending_TimeLabel.Size = New System.Drawing.Size(91, 17)
        Ending_TimeLabel.TabIndex = 61
        Ending_TimeLabel.Text = "Ending Time:"
        '
        'Starting_TimeLabel
        '
        Starting_TimeLabel.AutoSize = True
        Starting_TimeLabel.Location = New System.Drawing.Point(494, 268)
        Starting_TimeLabel.Name = "Starting_TimeLabel"
        Starting_TimeLabel.Size = New System.Drawing.Size(96, 17)
        Starting_TimeLabel.TabIndex = 58
        Starting_TimeLabel.Text = "Starting Time:"
        '
        'Estimated_No__of_ParticipantsLabel
        '
        Estimated_No__of_ParticipantsLabel.AutoSize = True
        Estimated_No__of_ParticipantsLabel.Location = New System.Drawing.Point(396, 223)
        Estimated_No__of_ParticipantsLabel.Name = "Estimated_No__of_ParticipantsLabel"
        Estimated_No__of_ParticipantsLabel.Size = New System.Drawing.Size(194, 17)
        Estimated_No__of_ParticipantsLabel.TabIndex = 57
        Estimated_No__of_ParticipantsLabel.Text = "Estimated No  of Participants:"
        '
        'Date_of_UseLabel
        '
        Date_of_UseLabel.AutoSize = True
        Date_of_UseLabel.Location = New System.Drawing.Point(503, 181)
        Date_of_UseLabel.Name = "Date_of_UseLabel"
        Date_of_UseLabel.Size = New System.Drawing.Size(87, 17)
        Date_of_UseLabel.TabIndex = 55
        Date_of_UseLabel.Text = "Date of Use:"
        '
        'Date_ReservedLabel
        '
        Date_ReservedLabel.AutoSize = True
        Date_ReservedLabel.Location = New System.Drawing.Point(483, 135)
        Date_ReservedLabel.Name = "Date_ReservedLabel"
        Date_ReservedLabel.Size = New System.Drawing.Size(107, 17)
        Date_ReservedLabel.TabIndex = 53
        Date_ReservedLabel.Text = "Date Reserved:"
        '
        'XU_ID_Label
        '
        XU_ID_Label.AutoSize = True
        XU_ID_Label.Location = New System.Drawing.Point(80, 225)
        XU_ID_Label.Name = "XU_ID_Label"
        XU_ID_Label.Size = New System.Drawing.Size(56, 17)
        XU_ID_Label.TabIndex = 51
        XU_ID_Label.Text = "XU ID#:"
        '
        'Contact_Label
        '
        Contact_Label.AutoSize = True
        Contact_Label.Location = New System.Drawing.Point(68, 182)
        Contact_Label.Name = "Contact_Label"
        Contact_Label.Size = New System.Drawing.Size(68, 17)
        Contact_Label.TabIndex = 49
        Contact_Label.Text = "Contact#:"
        '
        'NameLabel
        '
        NameLabel.AutoSize = True
        NameLabel.Location = New System.Drawing.Point(87, 136)
        NameLabel.Name = "NameLabel"
        NameLabel.Size = New System.Drawing.Size(49, 17)
        NameLabel.TabIndex = 47
        NameLabel.Text = "Name:"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(50, 609)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(117, 36)
        Me.Button3.TabIndex = 73
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"1 Court", "2 Courts", "Stage", "Green Room", "Without Light", "With Light"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(142, 375)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(200, 106)
        Me.CheckedListBox1.TabIndex = 71
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(679, 609)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(117, 36)
        Me.Button1.TabIndex = 68
        Me.Button1.Text = "Reserved"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Reserved_byTextBox
        '
        Me.Reserved_byTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Reserved by", True))
        Me.Reserved_byTextBox.Location = New System.Drawing.Point(142, 314)
        Me.Reserved_byTextBox.Name = "Reserved_byTextBox"
        Me.Reserved_byTextBox.Size = New System.Drawing.Size(200, 22)
        Me.Reserved_byTextBox.TabIndex = 66
        '
        'TableBindingSource
        '
        Me.TableBindingSource.DataMember = "Table"
        Me.TableBindingSource.DataSource = Me.Database2DataSet
        '
        'Database2DataSet
        '
        Me.Database2DataSet.DataSetName = "Database2DataSet"
        Me.Database2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OrganizerTextBox
        '
        Me.OrganizerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Organizer", True))
        Me.OrganizerTextBox.Location = New System.Drawing.Point(142, 266)
        Me.OrganizerTextBox.Name = "OrganizerTextBox"
        Me.OrganizerTextBox.Size = New System.Drawing.Size(200, 22)
        Me.OrganizerTextBox.TabIndex = 64
        '
        'Ending_TimeDateTimePicker
        '
        Me.Ending_TimeDateTimePicker.CustomFormat = "hh:mm:tt"
        Me.Ending_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Ending Time", True))
        Me.Ending_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Ending_TimeDateTimePicker.Location = New System.Drawing.Point(596, 312)
        Me.Ending_TimeDateTimePicker.Name = "Ending_TimeDateTimePicker"
        Me.Ending_TimeDateTimePicker.ShowUpDown = True
        Me.Ending_TimeDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Ending_TimeDateTimePicker.TabIndex = 62
        '
        'Starting_TimeDateTimePicker
        '
        Me.Starting_TimeDateTimePicker.CustomFormat = "hh:mm:tt"
        Me.Starting_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Starting Time", True))
        Me.Starting_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Starting_TimeDateTimePicker.Location = New System.Drawing.Point(596, 264)
        Me.Starting_TimeDateTimePicker.Name = "Starting_TimeDateTimePicker"
        Me.Starting_TimeDateTimePicker.ShowUpDown = True
        Me.Starting_TimeDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Starting_TimeDateTimePicker.TabIndex = 60
        '
        'Estimated_No__of_ParticipantsTextBox
        '
        Me.Estimated_No__of_ParticipantsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Estimated No_ of Participants", True))
        Me.Estimated_No__of_ParticipantsTextBox.Location = New System.Drawing.Point(596, 220)
        Me.Estimated_No__of_ParticipantsTextBox.Name = "Estimated_No__of_ParticipantsTextBox"
        Me.Estimated_No__of_ParticipantsTextBox.Size = New System.Drawing.Size(200, 22)
        Me.Estimated_No__of_ParticipantsTextBox.TabIndex = 59
        '
        'Date_of_UseDateTimePicker
        '
        Me.Date_of_UseDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date of Use", True))
        Me.Date_of_UseDateTimePicker.Location = New System.Drawing.Point(596, 177)
        Me.Date_of_UseDateTimePicker.Name = "Date_of_UseDateTimePicker"
        Me.Date_of_UseDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Date_of_UseDateTimePicker.TabIndex = 56
        '
        'Date_ReservedDateTimePicker
        '
        Me.Date_ReservedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date Reserved", True))
        Me.Date_ReservedDateTimePicker.Location = New System.Drawing.Point(596, 131)
        Me.Date_ReservedDateTimePicker.Name = "Date_ReservedDateTimePicker"
        Me.Date_ReservedDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Date_ReservedDateTimePicker.TabIndex = 54
        '
        'TableTableAdapter
        '
        Me.TableTableAdapter.ClearBeforeFill = True
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(556, 609)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(117, 36)
        Me.Button2.TabIndex = 67
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.TableTableAdapter = Me.TableTableAdapter
        Me.TableAdapterManager.UpdateOrder = Court.Database2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Items.AddRange(New Object() {"Security Guard", "Janitor", "Electrician", "Sound System", "Sound System Operator", "Tables", "Mono-blocks"})
        Me.CheckedListBox2.Location = New System.Drawing.Point(598, 371)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(200, 123)
        Me.CheckedListBox2.TabIndex = 72
        '
        'XU_ID_TextBox
        '
        Me.XU_ID_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "XU ID#", True))
        Me.XU_ID_TextBox.Location = New System.Drawing.Point(142, 222)
        Me.XU_ID_TextBox.Name = "XU_ID_TextBox"
        Me.XU_ID_TextBox.Size = New System.Drawing.Size(200, 22)
        Me.XU_ID_TextBox.TabIndex = 52
        '
        'Contact_TextBox
        '
        Me.Contact_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Contact#", True))
        Me.Contact_TextBox.Location = New System.Drawing.Point(142, 179)
        Me.Contact_TextBox.Name = "Contact_TextBox"
        Me.Contact_TextBox.Size = New System.Drawing.Size(200, 22)
        Me.Contact_TextBox.TabIndex = 50
        '
        'NameTextBox
        '
        Me.NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Name", True))
        Me.NameTextBox.Location = New System.Drawing.Point(142, 133)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(200, 22)
        Me.NameTextBox.TabIndex = 48
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 63)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(845, 11)
        Me.Panel2.TabIndex = 78
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(845, 63)
        Me.Panel1.TabIndex = 77
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(190, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(472, 41)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "COVERED COURT RESERVATION"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(173, 609)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(117, 36)
        Me.Button4.TabIndex = 79
        Me.Button4.Text = "View"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(788, 9)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 80
        Me.PictureBox3.TabStop = False
        '
        'Court1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Reserved_byTextBox)
        Me.Controls.Add(Me.OrganizerTextBox)
        Me.Controls.Add(Me.Ending_TimeDateTimePicker)
        Me.Controls.Add(Me.Starting_TimeDateTimePicker)
        Me.Controls.Add(Me.Estimated_No__of_ParticipantsTextBox)
        Me.Controls.Add(Me.Date_of_UseDateTimePicker)
        Me.Controls.Add(Me.Date_ReservedDateTimePicker)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.CheckedListBox2)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Reserved_byLabel)
        Me.Controls.Add(OrganizerLabel)
        Me.Controls.Add(Ending_TimeLabel)
        Me.Controls.Add(Starting_TimeLabel)
        Me.Controls.Add(Estimated_No__of_ParticipantsLabel)
        Me.Controls.Add(Date_of_UseLabel)
        Me.Controls.Add(Date_ReservedLabel)
        Me.Controls.Add(XU_ID_Label)
        Me.Controls.Add(Me.XU_ID_TextBox)
        Me.Controls.Add(Contact_Label)
        Me.Controls.Add(Me.Contact_TextBox)
        Me.Controls.Add(NameLabel)
        Me.Controls.Add(Me.NameTextBox)
        Me.Name = "Court1"
        Me.Size = New System.Drawing.Size(845, 674)
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button3 As Button
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Reserved_byTextBox As TextBox
    Friend WithEvents TableBindingSource As BindingSource
    Friend WithEvents Database2DataSet As Court.Database2DataSet
    Friend WithEvents OrganizerTextBox As TextBox
    Friend WithEvents Ending_TimeDateTimePicker As DateTimePicker
    Friend WithEvents Starting_TimeDateTimePicker As DateTimePicker
    Friend WithEvents Estimated_No__of_ParticipantsTextBox As TextBox
    Friend WithEvents Date_of_UseDateTimePicker As DateTimePicker
    Friend WithEvents Date_ReservedDateTimePicker As DateTimePicker
    Friend WithEvents TableTableAdapter As Court.Database2DataSetTableAdapters.TableTableAdapter
    Friend WithEvents Button2 As Button
    Friend WithEvents TableAdapterManager As Court.Database2DataSetTableAdapters.TableAdapterManager
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents XU_ID_TextBox As TextBox
    Friend WithEvents Contact_TextBox As TextBox
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox3 As PictureBox
End Class
