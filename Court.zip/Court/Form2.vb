﻿Public Class Form2

    Dim isHide As Boolean
    Dim pw As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form4.Show()


    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If isHide Then
            panelSlidebar.Width = panelSlidebar.Width + 5

            If panelSlidebar.Width >= 180 Then
                Timer1.Stop()
                isHide = False
                Refresh()
            End If

        Else
            panelSlidebar.Width = panelSlidebar.Width - 5

            If panelSlidebar.Width <= 0 Then
                Timer1.Stop()
                isHide = True
                Refresh()


            End If
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click, PictureBox3.Click, PictureBox8.Click, PictureBox7.Click, PictureBox6.Click, PictureBox5.Click, PictureBox4.Click


        Timer1.Start()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Close()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Me.Close()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pw = panelSlidebar.Width
        isHide = True




    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.Hide()
        Form6.Show()
    End Sub
End Class