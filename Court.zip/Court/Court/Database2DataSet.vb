﻿Partial Class Database2DataSet
    Partial Public Class TableDataTable
    End Class
End Class

Namespace Database2DataSetTableAdapters
    Partial Public Class Table1TableAdapter
    End Class

    Partial Public Class TableTableAdapter
    End Class
End Namespace

Namespace Database2DataSetTableAdapters
    Partial Public Class TableTableAdapter
    End Class
End Namespace
