﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Venue_NameLabel As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Reserved_byLabel As System.Windows.Forms.Label
        Dim OrganizerLabel As System.Windows.Forms.Label
        Dim Ending_TimeLabel As System.Windows.Forms.Label
        Dim Starting_TimeLabel As System.Windows.Forms.Label
        Dim Estimated_No__of_ParticipantsLabel As System.Windows.Forms.Label
        Dim Date_of_UseLabel As System.Windows.Forms.Label
        Dim XU_ID_Label As System.Windows.Forms.Label
        Dim Contact_Label As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.Venue_NameComboBox = New System.Windows.Forms.ComboBox()
        Me.TableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database2DataSet = New Court.Database2DataSet()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TableTableAdapter = New Court.Database2DataSetTableAdapters.TableTableAdapter()
        Me.TableAdapterManager = New Court.Database2DataSetTableAdapters.TableAdapterManager()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Reserved_byTextBox = New System.Windows.Forms.TextBox()
        Me.OrganizerTextBox = New System.Windows.Forms.TextBox()
        Me.Ending_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Starting_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Estimated_No__of_ParticipantsTextBox = New System.Windows.Forms.TextBox()
        Me.Date_of_UseDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Date_ReservedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.XU_ID_TextBox = New System.Windows.Forms.TextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Contact_TextBox = New System.Windows.Forms.TextBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Venue_NameLabel = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Reserved_byLabel = New System.Windows.Forms.Label()
        OrganizerLabel = New System.Windows.Forms.Label()
        Ending_TimeLabel = New System.Windows.Forms.Label()
        Starting_TimeLabel = New System.Windows.Forms.Label()
        Estimated_No__of_ParticipantsLabel = New System.Windows.Forms.Label()
        Date_of_UseLabel = New System.Windows.Forms.Label()
        XU_ID_Label = New System.Windows.Forms.Label()
        Contact_Label = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Venue_NameLabel
        '
        Venue_NameLabel.AutoSize = True
        Venue_NameLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Venue_NameLabel.Location = New System.Drawing.Point(32, 109)
        Venue_NameLabel.Name = "Venue_NameLabel"
        Venue_NameLabel.Size = New System.Drawing.Size(114, 23)
        Venue_NameLabel.TabIndex = 105
        Venue_NameLabel.Text = "Venue Name:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.Location = New System.Drawing.Point(376, 385)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(231, 23)
        Label3.TabIndex = 100
        Label3.Text = "Manpower and Other Needs:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.Location = New System.Drawing.Point(37, 381)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(98, 23)
        Label2.TabIndex = 99
        Label2.Text = "Facility Use:"
        '
        'Reserved_byLabel
        '
        Reserved_byLabel.AutoSize = True
        Reserved_byLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Reserved_byLabel.Location = New System.Drawing.Point(34, 321)
        Reserved_byLabel.Name = "Reserved_byLabel"
        Reserved_byLabel.Size = New System.Drawing.Size(105, 23)
        Reserved_byLabel.TabIndex = 95
        Reserved_byLabel.Text = "Reserved by:"
        AddHandler Reserved_byLabel.Click, AddressOf Me.Reserved_byLabel_Click
        '
        'OrganizerLabel
        '
        OrganizerLabel.AutoSize = True
        OrganizerLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        OrganizerLabel.Location = New System.Drawing.Point(51, 265)
        OrganizerLabel.Name = "OrganizerLabel"
        OrganizerLabel.Size = New System.Drawing.Size(89, 23)
        OrganizerLabel.TabIndex = 93
        OrganizerLabel.Text = "Organizer:"
        '
        'Ending_TimeLabel
        '
        Ending_TimeLabel.AutoSize = True
        Ending_TimeLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Ending_TimeLabel.Location = New System.Drawing.Point(498, 318)
        Ending_TimeLabel.Name = "Ending_TimeLabel"
        Ending_TimeLabel.Size = New System.Drawing.Size(109, 23)
        Ending_TimeLabel.TabIndex = 91
        Ending_TimeLabel.Text = "Ending Time:"
        AddHandler Ending_TimeLabel.Click, AddressOf Me.Ending_TimeLabel_Click
        '
        'Starting_TimeLabel
        '
        Starting_TimeLabel.AutoSize = True
        Starting_TimeLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Starting_TimeLabel.Location = New System.Drawing.Point(491, 265)
        Starting_TimeLabel.Name = "Starting_TimeLabel"
        Starting_TimeLabel.Size = New System.Drawing.Size(116, 23)
        Starting_TimeLabel.TabIndex = 88
        Starting_TimeLabel.Text = "Starting Time:"
        '
        'Estimated_No__of_ParticipantsLabel
        '
        Estimated_No__of_ParticipantsLabel.AutoSize = True
        Estimated_No__of_ParticipantsLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Estimated_No__of_ParticipantsLabel.Location = New System.Drawing.Point(371, 209)
        Estimated_No__of_ParticipantsLabel.Name = "Estimated_No__of_ParticipantsLabel"
        Estimated_No__of_ParticipantsLabel.Size = New System.Drawing.Size(236, 23)
        Estimated_No__of_ParticipantsLabel.TabIndex = 87
        Estimated_No__of_ParticipantsLabel.Text = "Estimated No  of Participants:"
        '
        'Date_of_UseLabel
        '
        Date_of_UseLabel.AutoSize = True
        Date_of_UseLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Date_of_UseLabel.Location = New System.Drawing.Point(504, 156)
        Date_of_UseLabel.Name = "Date_of_UseLabel"
        Date_of_UseLabel.Size = New System.Drawing.Size(103, 23)
        Date_of_UseLabel.TabIndex = 85
        Date_of_UseLabel.Text = "Date of Use:"
        '
        'XU_ID_Label
        '
        XU_ID_Label.AutoSize = True
        XU_ID_Label.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        XU_ID_Label.Location = New System.Drawing.Point(72, 212)
        XU_ID_Label.Name = "XU_ID_Label"
        XU_ID_Label.Size = New System.Drawing.Size(68, 23)
        XU_ID_Label.TabIndex = 81
        XU_ID_Label.Text = "XU ID#:"
        '
        'Contact_Label
        '
        Contact_Label.AutoSize = True
        Contact_Label.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Contact_Label.Location = New System.Drawing.Point(60, 161)
        Contact_Label.Name = "Contact_Label"
        Contact_Label.Size = New System.Drawing.Size(84, 23)
        Contact_Label.TabIndex = 79
        Contact_Label.Text = "Contact#:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.Location = New System.Drawing.Point(484, 114)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(123, 23)
        Label4.TabIndex = 107
        Label4.Text = "Date Reserved:"
        '
        'Venue_NameComboBox
        '
        Me.Venue_NameComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.Venue_NameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Venue Name", True))
        Me.Venue_NameComboBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Venue_NameComboBox.FormattingEnabled = True
        Me.Venue_NameComboBox.Items.AddRange(New Object() {"Gymnasium", "Covered Courts", "Soccer Field"})
        Me.Venue_NameComboBox.Location = New System.Drawing.Point(163, 106)
        Me.Venue_NameComboBox.Name = "Venue_NameComboBox"
        Me.Venue_NameComboBox.Size = New System.Drawing.Size(200, 31)
        Me.Venue_NameComboBox.TabIndex = 106
        '
        'TableBindingSource
        '
        Me.TableBindingSource.DataMember = "Table"
        Me.TableBindingSource.DataSource = Me.Database2DataSet
        '
        'Database2DataSet
        '
        Me.Database2DataSet.DataSetName = "Database2DataSet"
        Me.Database2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button4.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(163, 576)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(125, 44)
        Me.Button4.TabIndex = 104
        Me.Button4.Text = "View"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TableTableAdapter
        '
        Me.TableTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Table1TableAdapter = Nothing
        Me.TableAdapterManager.Table2TableAdapter = Nothing
        Me.TableAdapterManager.TableTableAdapter = Me.TableTableAdapter
        Me.TableAdapterManager.UpdateOrder = Court.Database2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(40, 576)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(125, 44)
        Me.Button3.TabIndex = 103
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Items.AddRange(New Object() {"Security Guard", "Janitor", "Electrician", "Sound System", "Sound System Operator", "Tables", "Mono-blocks"})
        Me.CheckedListBox2.Location = New System.Drawing.Point(627, 381)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(200, 104)
        Me.CheckedListBox2.TabIndex = 102
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(163, 385)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(200, 104)
        Me.CheckedListBox1.TabIndex = 101
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(289, 576)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 44)
        Me.Button1.TabIndex = 98
        Me.Button1.Text = "Reserved"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Reserved_byTextBox
        '
        Me.Reserved_byTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Reserved_byTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Reserved by", True))
        Me.Reserved_byTextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Reserved_byTextBox.Location = New System.Drawing.Point(163, 318)
        Me.Reserved_byTextBox.Name = "Reserved_byTextBox"
        Me.Reserved_byTextBox.Size = New System.Drawing.Size(200, 30)
        Me.Reserved_byTextBox.TabIndex = 96
        '
        'OrganizerTextBox
        '
        Me.OrganizerTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.OrganizerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Organizer", True))
        Me.OrganizerTextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.OrganizerTextBox.Location = New System.Drawing.Point(163, 262)
        Me.OrganizerTextBox.Name = "OrganizerTextBox"
        Me.OrganizerTextBox.Size = New System.Drawing.Size(202, 30)
        Me.OrganizerTextBox.TabIndex = 94
        '
        'Ending_TimeDateTimePicker
        '
        Me.Ending_TimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.Ending_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Ending Time", True))
        Me.Ending_TimeDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Ending_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Ending_TimeDateTimePicker.Location = New System.Drawing.Point(625, 316)
        Me.Ending_TimeDateTimePicker.Name = "Ending_TimeDateTimePicker"
        Me.Ending_TimeDateTimePicker.ShowUpDown = True
        Me.Ending_TimeDateTimePicker.Size = New System.Drawing.Size(202, 30)
        Me.Ending_TimeDateTimePicker.TabIndex = 92
        '
        'Starting_TimeDateTimePicker
        '
        Me.Starting_TimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.Starting_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Starting Time", True))
        Me.Starting_TimeDateTimePicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.Starting_TimeDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Starting_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Starting_TimeDateTimePicker.Location = New System.Drawing.Point(625, 260)
        Me.Starting_TimeDateTimePicker.MinDate = New Date(2020, 2, 25, 0, 0, 0, 0)
        Me.Starting_TimeDateTimePicker.Name = "Starting_TimeDateTimePicker"
        Me.Starting_TimeDateTimePicker.ShowUpDown = True
        Me.Starting_TimeDateTimePicker.Size = New System.Drawing.Size(202, 30)
        Me.Starting_TimeDateTimePicker.TabIndex = 90
        '
        'Estimated_No__of_ParticipantsTextBox
        '
        Me.Estimated_No__of_ParticipantsTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Estimated_No__of_ParticipantsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Estimated No_ of Participants", True))
        Me.Estimated_No__of_ParticipantsTextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Estimated_No__of_ParticipantsTextBox.Location = New System.Drawing.Point(627, 207)
        Me.Estimated_No__of_ParticipantsTextBox.Name = "Estimated_No__of_ParticipantsTextBox"
        Me.Estimated_No__of_ParticipantsTextBox.Size = New System.Drawing.Size(200, 30)
        Me.Estimated_No__of_ParticipantsTextBox.TabIndex = 89
        '
        'Date_of_UseDateTimePicker
        '
        Me.Date_of_UseDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date of Use", True))
        Me.Date_of_UseDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Date_of_UseDateTimePicker.Location = New System.Drawing.Point(627, 156)
        Me.Date_of_UseDateTimePicker.Name = "Date_of_UseDateTimePicker"
        Me.Date_of_UseDateTimePicker.Size = New System.Drawing.Size(200, 30)
        Me.Date_of_UseDateTimePicker.TabIndex = 86
        '
        'Date_ReservedDateTimePicker
        '
        Me.Date_ReservedDateTimePicker.CalendarMonthBackground = System.Drawing.Color.White
        Me.Date_ReservedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date Reserved", True))
        Me.Date_ReservedDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Date_ReservedDateTimePicker.Location = New System.Drawing.Point(627, 109)
        Me.Date_ReservedDateTimePicker.Name = "Date_ReservedDateTimePicker"
        Me.Date_ReservedDateTimePicker.Size = New System.Drawing.Size(200, 30)
        Me.Date_ReservedDateTimePicker.TabIndex = 84
        '
        'XU_ID_TextBox
        '
        Me.XU_ID_TextBox.BackColor = System.Drawing.SystemColors.Window
        Me.XU_ID_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "XU ID#", True))
        Me.XU_ID_TextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.XU_ID_TextBox.Location = New System.Drawing.Point(165, 209)
        Me.XU_ID_TextBox.Name = "XU_ID_TextBox"
        Me.XU_ID_TextBox.Size = New System.Drawing.Size(200, 30)
        Me.XU_ID_TextBox.TabIndex = 82
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(819, 9)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 78
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(267, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(325, 41)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "VENUE RESERVATION"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(876, 63)
        Me.Panel1.TabIndex = 78
        '
        'Contact_TextBox
        '
        Me.Contact_TextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Contact_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Contact#", True))
        Me.Contact_TextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!)
        Me.Contact_TextBox.Location = New System.Drawing.Point(165, 158)
        Me.Contact_TextBox.Name = "Contact_TextBox"
        Me.Contact_TextBox.Size = New System.Drawing.Size(200, 30)
        Me.Contact_TextBox.TabIndex = 80
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(876, 630)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Me.Venue_NameComboBox)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Venue_NameLabel)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.CheckedListBox2)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Reserved_byLabel)
        Me.Controls.Add(Me.Reserved_byTextBox)
        Me.Controls.Add(OrganizerLabel)
        Me.Controls.Add(Me.OrganizerTextBox)
        Me.Controls.Add(Ending_TimeLabel)
        Me.Controls.Add(Me.Ending_TimeDateTimePicker)
        Me.Controls.Add(Starting_TimeLabel)
        Me.Controls.Add(Me.Starting_TimeDateTimePicker)
        Me.Controls.Add(Estimated_No__of_ParticipantsLabel)
        Me.Controls.Add(Me.Estimated_No__of_ParticipantsTextBox)
        Me.Controls.Add(Date_of_UseLabel)
        Me.Controls.Add(Me.Date_of_UseDateTimePicker)
        Me.Controls.Add(Me.Date_ReservedDateTimePicker)
        Me.Controls.Add(XU_ID_Label)
        Me.Controls.Add(Me.XU_ID_TextBox)
        Me.Controls.Add(Contact_Label)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Contact_TextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form4"
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Gym2 As Gym
    Public WithEvents Venue_NameComboBox As ComboBox
    Friend WithEvents TableBindingSource As BindingSource
    Friend WithEvents Database2DataSet As Database2DataSet
    Friend WithEvents Button4 As Button
    Friend WithEvents TableTableAdapter As Database2DataSetTableAdapters.TableTableAdapter
    Friend WithEvents TableAdapterManager As Database2DataSetTableAdapters.TableAdapterManager
    Friend WithEvents Button3 As Button
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Reserved_byTextBox As TextBox
    Friend WithEvents OrganizerTextBox As TextBox
    Friend WithEvents Ending_TimeDateTimePicker As DateTimePicker
    Friend WithEvents Starting_TimeDateTimePicker As DateTimePicker
    Friend WithEvents Estimated_No__of_ParticipantsTextBox As TextBox
    Friend WithEvents Date_of_UseDateTimePicker As DateTimePicker
    Friend WithEvents Date_ReservedDateTimePicker As DateTimePicker
    Friend WithEvents XU_ID_TextBox As TextBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Contact_TextBox As TextBox
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
