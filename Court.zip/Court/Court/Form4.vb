﻿Public Class Form4

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ChkBox1Val As String
        Dim ChkBox2Val As String
        If String.IsNullOrWhiteSpace(Venue_NameComboBox.Text) = False And String.IsNullOrWhiteSpace(Contact_TextBox.Text) = False And String.IsNullOrWhiteSpace(XU_ID_TextBox.Text) = False And String.IsNullOrWhiteSpace(Estimated_No__of_ParticipantsTextBox.Text) = False And String.IsNullOrWhiteSpace(OrganizerTextBox.Text) = False And String.IsNullOrWhiteSpace(Reserved_byTextBox.Text) = False Then

            If CheckedListBox1.CheckedItems.Count > 0 Then
                For i As Integer = 0 To CheckedListBox1.CheckedItems.Count - 1
                    If ChkBox1Val = "" Then
                        ChkBox1Val = CheckedListBox1.CheckedItems(i)
                    Else
                        ChkBox1Val += ", " + CheckedListBox1.CheckedItems(i)
                    End If
                Next
            End If

            If CheckedListBox2.CheckedItems.Count > 0 Then
                For i As Integer = 0 To CheckedListBox2.CheckedItems.Count - 1
                    If ChkBox2Val = "" Then
                        ChkBox2Val = CheckedListBox2.CheckedItems(i)
                    Else
                        ChkBox2Val += ", " + CheckedListBox2.CheckedItems(i)
                    End If
                Next
            End If
            Dim count As Integer
            If Starting_TimeDateTimePicker.Value > DateTime.Now And Ending_TimeDateTimePicker.Value > DateTime.Now Then
                count = Me.TableTableAdapter.SeeConflict(Venue_NameComboBox.Text, Date_of_UseDateTimePicker.Value, Starting_TimeDateTimePicker.Value, Ending_TimeDateTimePicker.Value)
                If count = 0 Then
                    Me.TableTableAdapter.InsertQuery(Venue_NameComboBox.Text, Contact_TextBox.Text, XU_ID_TextBox.Text, Date_ReservedDateTimePicker.Value,
                                          Date_of_UseDateTimePicker.Value, Estimated_No__of_ParticipantsTextBox.Text, Starting_TimeDateTimePicker.Value, Ending_TimeDateTimePicker.Value, OrganizerTextBox.Text,
                                          Reserved_byTextBox.Text, ChkBox1Val, ChkBox2Val, "Reserved")
                    Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
                    Ending_TimeDateTimePicker.Text = ""
                    Venue_NameComboBox.Text = ""
                    Contact_TextBox.Text = ""
                    XU_ID_TextBox.Text = ""
                    OrganizerTextBox.Text = ""
                    Reserved_byTextBox.Text = ""
                    Estimated_No__of_ParticipantsTextBox.Text = ""
                    Date_of_UseDateTimePicker.Text = ""
                    Starting_TimeDateTimePicker.Text = ""
                    Ending_TimeDateTimePicker.Text = ""
                    MessageBox.Show("Reserved")
                Else
                    ErrorProvider1.SetError(Starting_TimeDateTimePicker, "Conflict in Time reservation. Please edit starting time inputs")
                    ErrorProvider1.SetError(Ending_TimeDateTimePicker, "Conflict in Time reservation. Please edit ending time inputs")
                End If
            Else
                ErrorProvider1.SetError(Starting_TimeDateTimePicker, "Starting time must not be before current running time.")
                ErrorProvider1.SetError(Ending_TimeDateTimePicker, "Ending time must not be before current running time.")
            End If
        Else
            MessageBox.Show("At least one textbox is empty")
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Venue_NameComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Venue_NameComboBox.SelectedIndexChanged
        If Venue_NameComboBox.Text = "Gymnasium" Then
            CheckedListBox1.Items.Clear()
            CheckedListBox1.Items.Add("1st Floor Only")
            CheckedListBox1.Items.Add("1st Floor and 2nd floor")
            CheckedListBox1.Items.Add("Stage")
            CheckedListBox1.Items.Add("Dug-Out")
            CheckedListBox1.Items.Add("Bleachers")
            CheckedListBox1.Items.Add("Without Light")
            CheckedListBox1.Items.Add("With Light")
        End If

        If Venue_NameComboBox.Text = "Covered Courts" Then
            CheckedListBox1.Items.Clear()
            CheckedListBox1.Items.Add("Half of the Field")
            CheckedListBox1.Items.Add("Whole Field")
            CheckedListBox1.Items.Add("Without Light")
            CheckedListBox1.Items.Add("With Light")
        End If

        If Venue_NameComboBox.Text = "Soccer Field" Then
            CheckedListBox1.Items.Clear()
            CheckedListBox1.Items.Add("1 Court")
            CheckedListBox1.Items.Add("2 Courts")
            CheckedListBox1.Items.Add("Stage")
            CheckedListBox1.Items.Add("Green Room")
            CheckedListBox1.Items.Add("Without Light")
            CheckedListBox1.Items.Add("With Light")
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Date_ReservedDateTimePicker.Enabled = False
    End Sub

    Private Sub Reserved_byLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Reserved_byTextBox_TextChanged(sender As Object, e As EventArgs) Handles Reserved_byTextBox.TextChanged

    End Sub

    Private Sub Ending_TimeLabel_Click(sender As Object, e As EventArgs)

    End Sub


End Class