﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Try
            If EmailTextBox.Text.Contains("@") And EmailTextBox.Text.Contains(".com") Then
                If IsNumeric(Contact_NumberTextBox.Text) Then
                    If IsNumeric(XU_IDTextBox.Text) Then
                        If String.IsNullOrWhiteSpace(First_NameTextBox.Text) = False And String.IsNullOrWhiteSpace(Middle_NameTextBox.Text) = False And String.IsNullOrWhiteSpace(Last_NameTextBox.Text) = False And String.IsNullOrWhiteSpace(XU_IDTextBox.Text) = False And String.IsNullOrWhiteSpace(UsernameTextBox.Text) = False And String.IsNullOrWhiteSpace(PasswordTextBox.Text) = False And String.IsNullOrWhiteSpace(EmailTextBox.Text) = False And String.IsNullOrWhiteSpace(Contact_NumberTextBox.Text) = False Then

                            Me.TableTableAdapter.InsertQuery(UsernameTextBox.Text, PasswordTextBox.Text, First_NameTextBox.Text, Middle_NameTextBox.Text, Last_NameTextBox.Text,
                                            XU_IDTextBox.Text,
                                            EmailTextBox.Text, Contact_NumberTextBox.Text)
                            Me.TableTableAdapter.Fill(Me.Database1DataSet.Table)
                            UsernameTextBox.Text = ""
                            PasswordTextBox.Text = ""
                            First_NameTextBox.Text = ""
                            Middle_NameTextBox.Text = ""
                            Last_NameTextBox.Text = ""
                            XU_IDTextBox.Text = ""
                            EmailTextBox.Text = ""
                            Contact_NumberTextBox.Text = ""

                            MsgBox("Registered Successfully")

                        Else
                            MessageBox.Show("One or more textboxes empty. Please fill in")
                        End If
                    Else
                        ErrorProvider1.SetError(XU_IDTextBox, "Use number charaters.")
                    End If
                Else
                        ErrorProvider1.SetError(Contact_NumberTextBox, "Use number charaters.")
                End If
            Else
                    ErrorProvider1.SetError(EmailTextBox, "Must be a valid email address.")
            End If
        Catch ex As Exception
        End Try

    End Sub



    Private Sub PictureBox9_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub PictureBox9_Click_1(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        UsernameTextBox.Text = ""
        PasswordTextBox.Text = ""
        First_NameTextBox.Text = ""
        Middle_NameTextBox.Text = ""
        Last_NameTextBox.Text = ""
        XU_IDTextBox.Text = ""
        EmailTextBox.Text = ""
        Contact_NumberTextBox.Text = ""
    End Sub


End Class