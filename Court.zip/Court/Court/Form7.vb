﻿Imports System.Data.SqlClient

Public Class Form7
    Dim table As New DataTable()
    Dim f As New Form6


    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database2DataSet.Table2' table. You can move, or remove it, as needed.
        PopulateComboBox()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If ItemStartingTimeDateTimePicker.Value > DateTime.Now And ItemEndingTimeDateTimePicker.Value > DateTime.Now Then
            If String.IsNullOrWhiteSpace(ItemNameComboBox.Text) = False And String.IsNullOrWhiteSpace(ItemQuantityTextBox.Text) = False And String.IsNullOrWhiteSpace(ContactNumTextBox.Text) = False And String.IsNullOrWhiteSpace(ItemReserverNameTextBox.Text) = False Then
                Me.Table2TableAdapter.InsertQuery(ItemNameComboBox.Text, ItemQuantityTextBox.Text, ItemReserverNameTextBox.Text, ContactNumTextBox.Text, ItemDateReservedDateTimePicker.Value, ItemStartingTimeDateTimePicker.Value, ItemEndingTimeDateTimePicker.Value)
            Else
                MessageBox.Show("At least one textbox is empty. Please fill in")
            End If
        Else
            MessageBox.Show("Starting and Ending time must not be before current time")
        End If
    End Sub

    Private Sub Table2DataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Table2DataGridView.RowHeaderMouseClick
        Try
            ItemNameComboBox.Text = Table2DataGridView.SelectedRows.Item(1).ToString
            ItemQuantityTextBox.Text = Table2DataGridView.SelectedRows.Item(2).ToString
            ItemReserverNameTextBox.Text = Table2DataGridView.SelectedRows.Item(3).ToString
            ContactNumTextBox.Text = Table2DataGridView.SelectedRows.Item(4).ToString
            ItemDateReservedDateTimePicker.Value = Table2DataGridView.SelectedRows.Item(5).ToString
            ItemStartingTimeDateTimePicker.Value = Table2DataGridView.SelectedRows.Item(6).ToString
            ItemEndingTimeDateTimePicker.Value = Table2DataGridView.SelectedRows.Item(7).ToString


        Catch ex As Exception
        End Try

    End Sub

    Private Sub PopulateComboBox()
        Try

            Me.Table1TableAdapter.FillName(ItemNameComboBox.DataSource)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form4.Show()
        Me.Hide()

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Form6.Show()
        Me.Hide()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Form5.Show()
        Me.Hide()

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        MessageBox.Show("Are you sure you want to logout?", "LOGOUT", MessageBoxButtons.OKCancel)
        If DialogResult.OK Then
            Me.Hide()
            Form1.Show()
        End If
    End Sub
End Class