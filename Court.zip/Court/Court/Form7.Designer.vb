﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ItemQuantityLabel As System.Windows.Forms.Label
        Dim ItemNameLabel As System.Windows.Forms.Label
        Dim ItemReserverNameLabel As System.Windows.Forms.Label
        Dim ContactNumLabel As System.Windows.Forms.Label
        Dim ItemDateReservedLabel As System.Windows.Forms.Label
        Dim ItemStartingTimeLabel As System.Windows.Forms.Label
        Dim ItemEndingTimeLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form7))
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Table1TableAdapter = New Court.Database2DataSetTableAdapters.Table1TableAdapter()
        Me.Table1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database2DataSet = New Court.Database2DataSet()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TableAdapterManager = New Court.Database2DataSetTableAdapters.TableAdapterManager()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.panelSlidebar2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Table2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Table2TableAdapter = New Court.Database2DataSetTableAdapters.Table2TableAdapter()
        Me.Table2DataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ItemQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.ItemNameComboBox = New System.Windows.Forms.ComboBox()
        Me.ItemReserverNameTextBox = New System.Windows.Forms.TextBox()
        Me.ContactNumTextBox = New System.Windows.Forms.TextBox()
        Me.ItemDateReservedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ItemStartingTimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ItemEndingTimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        ItemQuantityLabel = New System.Windows.Forms.Label()
        ItemNameLabel = New System.Windows.Forms.Label()
        ItemReserverNameLabel = New System.Windows.Forms.Label()
        ContactNumLabel = New System.Windows.Forms.Label()
        ItemDateReservedLabel = New System.Windows.Forms.Label()
        ItemStartingTimeLabel = New System.Windows.Forms.Label()
        ItemEndingTimeLabel = New System.Windows.Forms.Label()
        CType(Me.Table1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSlidebar2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Table2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Table2DataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ItemQuantityLabel
        '
        ItemQuantityLabel.AutoSize = True
        ItemQuantityLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ItemQuantityLabel.Location = New System.Drawing.Point(296, 473)
        ItemQuantityLabel.Name = "ItemQuantityLabel"
        ItemQuantityLabel.Size = New System.Drawing.Size(134, 23)
        ItemQuantityLabel.TabIndex = 62
        ItemQuantityLabel.Text = "Item Quantity:"
        '
        'ItemNameLabel
        '
        ItemNameLabel.AutoSize = True
        ItemNameLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ItemNameLabel.Location = New System.Drawing.Point(320, 424)
        ItemNameLabel.Name = "ItemNameLabel"
        ItemNameLabel.Size = New System.Drawing.Size(110, 23)
        ItemNameLabel.TabIndex = 63
        ItemNameLabel.Text = "Item Name:"
        '
        'ItemReserverNameLabel
        '
        ItemReserverNameLabel.AutoSize = True
        ItemReserverNameLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ItemReserverNameLabel.Location = New System.Drawing.Point(250, 520)
        ItemReserverNameLabel.Name = "ItemReserverNameLabel"
        ItemReserverNameLabel.Size = New System.Drawing.Size(188, 23)
        ItemReserverNameLabel.TabIndex = 64
        ItemReserverNameLabel.Text = "Item Reserver Name:"
        '
        'ContactNumLabel
        '
        ContactNumLabel.AutoSize = True
        ContactNumLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ContactNumLabel.Location = New System.Drawing.Point(301, 563)
        ContactNumLabel.Name = "ContactNumLabel"
        ContactNumLabel.Size = New System.Drawing.Size(129, 23)
        ContactNumLabel.TabIndex = 65
        ContactNumLabel.Text = "Contact Num:"
        '
        'ItemDateReservedLabel
        '
        ItemDateReservedLabel.AutoSize = True
        ItemDateReservedLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ItemDateReservedLabel.Location = New System.Drawing.Point(681, 421)
        ItemDateReservedLabel.Name = "ItemDateReservedLabel"
        ItemDateReservedLabel.Size = New System.Drawing.Size(182, 23)
        ItemDateReservedLabel.TabIndex = 66
        ItemDateReservedLabel.Text = "Item Date Reserved:"
        '
        'ItemStartingTimeLabel
        '
        ItemStartingTimeLabel.AutoSize = True
        ItemStartingTimeLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ItemStartingTimeLabel.Location = New System.Drawing.Point(690, 472)
        ItemStartingTimeLabel.Name = "ItemStartingTimeLabel"
        ItemStartingTimeLabel.Size = New System.Drawing.Size(175, 23)
        ItemStartingTimeLabel.TabIndex = 67
        ItemStartingTimeLabel.Text = "Item Starting Time:"
        '
        'ItemEndingTimeLabel
        '
        ItemEndingTimeLabel.AutoSize = True
        ItemEndingTimeLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ItemEndingTimeLabel.Location = New System.Drawing.Point(690, 523)
        ItemEndingTimeLabel.Name = "ItemEndingTimeLabel"
        ItemEndingTimeLabel.Size = New System.Drawing.Size(166, 23)
        ItemEndingTimeLabel.TabIndex = 68
        ItemEndingTimeLabel.Text = "Item Ending Time:"
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button8.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(12, 400)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(208, 55)
        Me.Button8.TabIndex = 2
        Me.Button8.Text = "     Equipment"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Symbol", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(547, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(214, 32)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "ADD EQUIPMENT"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(933, 680)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(125, 44)
        Me.Button2.TabIndex = 60
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(810, 680)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(125, 44)
        Me.Button3.TabIndex = 61
        Me.Button3.Text = "Add"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Table1TableAdapter
        '
        Me.Table1TableAdapter.ClearBeforeFill = True
        '
        'Table1BindingSource
        '
        Me.Table1BindingSource.DataMember = "Table1"
        Me.Table1BindingSource.DataSource = Me.Database2DataSet
        '
        'Database2DataSet
        '
        Me.Database2DataSet.DataSetName = "Database2DataSet"
        Me.Database2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1145, 78)
        Me.Panel1.TabIndex = 52
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(1088, 16)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(21, 24)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1145, 10)
        Me.Panel5.TabIndex = 2
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Table1TableAdapter = Me.Table1TableAdapter
        Me.TableAdapterManager.Table2TableAdapter = Nothing
        Me.TableAdapterManager.TableTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Court.Database2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'panelSlidebar2
        '
        Me.panelSlidebar2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.panelSlidebar2.Controls.Add(Me.PictureBox1)
        Me.panelSlidebar2.Controls.Add(Me.Label6)
        Me.panelSlidebar2.Controls.Add(Me.Label5)
        Me.panelSlidebar2.Controls.Add(Me.PictureBox14)
        Me.panelSlidebar2.Controls.Add(Me.PictureBox5)
        Me.panelSlidebar2.Controls.Add(Me.PictureBox11)
        Me.panelSlidebar2.Controls.Add(Me.PictureBox10)
        Me.panelSlidebar2.Controls.Add(Me.PictureBox9)
        Me.panelSlidebar2.Controls.Add(Me.Button10)
        Me.panelSlidebar2.Controls.Add(Me.Button1)
        Me.panelSlidebar2.Controls.Add(Me.Button11)
        Me.panelSlidebar2.Controls.Add(Me.Button9)
        Me.panelSlidebar2.Controls.Add(Me.Button8)
        Me.panelSlidebar2.Location = New System.Drawing.Point(0, 73)
        Me.panelSlidebar2.Name = "panelSlidebar2"
        Me.panelSlidebar2.Size = New System.Drawing.Size(236, 668)
        Me.panelSlidebar2.TabIndex = 53
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(90, 148)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(65, 63)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(59, 225)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 25)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "User Account"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(99, 265)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 25)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "User"
        '
        'PictureBox14
        '
        Me.PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), System.Drawing.Image)
        Me.PictureBox14.Location = New System.Drawing.Point(22, 325)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox14.TabIndex = 0
        Me.PictureBox14.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(21, 617)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 0
        Me.PictureBox5.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(24, 410)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 0
        Me.PictureBox11.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(22, 494)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 0
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(28, 6)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(176, 136)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 0
        Me.PictureBox9.TabStop = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button10.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.White
        Me.Button10.Location = New System.Drawing.Point(566, 633)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(195, 55)
        Me.Button10.TabIndex = 2
        Me.Button10.Text = "Log Out"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(12, 316)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(208, 55)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Venue"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button11.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.White
        Me.Button11.Location = New System.Drawing.Point(12, 607)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(208, 55)
        Me.Button11.TabIndex = 2
        Me.Button11.Text = " Log Out"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button9.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.White
        Me.Button9.Location = New System.Drawing.Point(12, 484)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(208, 55)
        Me.Button9.TabIndex = 2
        Me.Button9.Text = "       Reservation"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Table2BindingSource
        '
        Me.Table2BindingSource.DataMember = "Table2"
        Me.Table2BindingSource.DataSource = Me.Database2DataSet
        '
        'Table2TableAdapter
        '
        Me.Table2TableAdapter.ClearBeforeFill = True
        '
        'Table2DataGridView
        '
        Me.Table2DataGridView.AutoGenerateColumns = False
        Me.Table2DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Table2DataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8})
        Me.Table2DataGridView.DataSource = Me.Table2BindingSource
        Me.Table2DataGridView.Location = New System.Drawing.Point(282, 105)
        Me.Table2DataGridView.Name = "Table2DataGridView"
        Me.Table2DataGridView.RowHeadersWidth = 51
        Me.Table2DataGridView.RowTemplate.Height = 24
        Me.Table2DataGridView.Size = New System.Drawing.Size(801, 258)
        Me.Table2DataGridView.TabIndex = 61
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ItemReserveNum"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ItemReserveNum"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "ItemName"
        Me.DataGridViewTextBoxColumn2.HeaderText = "ItemName"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "ItemQuantity"
        Me.DataGridViewTextBoxColumn3.HeaderText = "ItemQuantity"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "ItemReserverName"
        Me.DataGridViewTextBoxColumn4.HeaderText = "ItemReserverName"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "ContactNum"
        Me.DataGridViewTextBoxColumn5.HeaderText = "ContactNum"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "ItemDateReserved"
        Me.DataGridViewTextBoxColumn6.HeaderText = "ItemDateReserved"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "ItemStartingTime"
        Me.DataGridViewTextBoxColumn7.HeaderText = "ItemStartingTime"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "ItemEndingTime"
        Me.DataGridViewTextBoxColumn8.HeaderText = "ItemEndingTime"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 125
        '
        'ItemQuantityTextBox
        '
        Me.ItemQuantityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table2BindingSource, "ItemQuantity", True))
        Me.ItemQuantityTextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemQuantityTextBox.Location = New System.Drawing.Point(456, 470)
        Me.ItemQuantityTextBox.Name = "ItemQuantityTextBox"
        Me.ItemQuantityTextBox.Size = New System.Drawing.Size(187, 30)
        Me.ItemQuantityTextBox.TabIndex = 63
        '
        'ItemNameComboBox
        '
        Me.ItemNameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table2BindingSource, "ItemName", True))
        Me.ItemNameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Table1BindingSource, "ItemName", True))
        Me.ItemNameComboBox.DataSource = Me.Table1BindingSource
        Me.ItemNameComboBox.DisplayMember = "ItemName"
        Me.ItemNameComboBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemNameComboBox.FormattingEnabled = True
        Me.ItemNameComboBox.Location = New System.Drawing.Point(456, 421)
        Me.ItemNameComboBox.Name = "ItemNameComboBox"
        Me.ItemNameComboBox.Size = New System.Drawing.Size(187, 31)
        Me.ItemNameComboBox.TabIndex = 64
        Me.ItemNameComboBox.ValueMember = "ItemNum"
        '
        'ItemReserverNameTextBox
        '
        Me.ItemReserverNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table2BindingSource, "ItemReserverName", True))
        Me.ItemReserverNameTextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemReserverNameTextBox.Location = New System.Drawing.Point(456, 516)
        Me.ItemReserverNameTextBox.Name = "ItemReserverNameTextBox"
        Me.ItemReserverNameTextBox.Size = New System.Drawing.Size(187, 30)
        Me.ItemReserverNameTextBox.TabIndex = 65
        '
        'ContactNumTextBox
        '
        Me.ContactNumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table2BindingSource, "ContactNum", True))
        Me.ContactNumTextBox.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContactNumTextBox.Location = New System.Drawing.Point(456, 560)
        Me.ContactNumTextBox.Name = "ContactNumTextBox"
        Me.ContactNumTextBox.Size = New System.Drawing.Size(187, 30)
        Me.ContactNumTextBox.TabIndex = 66
        '
        'ItemDateReservedDateTimePicker
        '
        Me.ItemDateReservedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.Table2BindingSource, "ItemDateReserved", True))
        Me.ItemDateReservedDateTimePicker.Enabled = False
        Me.ItemDateReservedDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemDateReservedDateTimePicker.Location = New System.Drawing.Point(883, 417)
        Me.ItemDateReservedDateTimePicker.Name = "ItemDateReservedDateTimePicker"
        Me.ItemDateReservedDateTimePicker.Size = New System.Drawing.Size(200, 30)
        Me.ItemDateReservedDateTimePicker.TabIndex = 67
        '
        'ItemStartingTimeDateTimePicker
        '
        Me.ItemStartingTimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.ItemStartingTimeDateTimePicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.ItemStartingTimeDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemStartingTimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ItemStartingTimeDateTimePicker.Location = New System.Drawing.Point(883, 467)
        Me.ItemStartingTimeDateTimePicker.MinDate = New Date(2020, 2, 25, 0, 0, 0, 0)
        Me.ItemStartingTimeDateTimePicker.Name = "ItemStartingTimeDateTimePicker"
        Me.ItemStartingTimeDateTimePicker.ShowUpDown = True
        Me.ItemStartingTimeDateTimePicker.Size = New System.Drawing.Size(200, 30)
        Me.ItemStartingTimeDateTimePicker.TabIndex = 91
        '
        'ItemEndingTimeDateTimePicker
        '
        Me.ItemEndingTimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.ItemEndingTimeDateTimePicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.ItemEndingTimeDateTimePicker.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemEndingTimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ItemEndingTimeDateTimePicker.Location = New System.Drawing.Point(883, 520)
        Me.ItemEndingTimeDateTimePicker.MinDate = New Date(2020, 2, 25, 0, 0, 0, 0)
        Me.ItemEndingTimeDateTimePicker.Name = "ItemEndingTimeDateTimePicker"
        Me.ItemEndingTimeDateTimePicker.ShowUpDown = True
        Me.ItemEndingTimeDateTimePicker.Size = New System.Drawing.Size(200, 30)
        Me.ItemEndingTimeDateTimePicker.TabIndex = 92
        '
        'Form7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1145, 738)
        Me.Controls.Add(Me.ItemEndingTimeDateTimePicker)
        Me.Controls.Add(Me.ItemStartingTimeDateTimePicker)
        Me.Controls.Add(ItemEndingTimeLabel)
        Me.Controls.Add(ItemStartingTimeLabel)
        Me.Controls.Add(ItemDateReservedLabel)
        Me.Controls.Add(Me.ItemDateReservedDateTimePicker)
        Me.Controls.Add(ContactNumLabel)
        Me.Controls.Add(Me.ContactNumTextBox)
        Me.Controls.Add(ItemReserverNameLabel)
        Me.Controls.Add(Me.ItemReserverNameTextBox)
        Me.Controls.Add(ItemNameLabel)
        Me.Controls.Add(Me.ItemNameComboBox)
        Me.Controls.Add(ItemQuantityLabel)
        Me.Controls.Add(Me.ItemQuantityTextBox)
        Me.Controls.Add(Me.Table2DataGridView)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.panelSlidebar2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form7"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form7"
        CType(Me.Table1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSlidebar2.ResumeLayout(False)
        Me.panelSlidebar2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Table2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Table2DataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button8 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Table1TableAdapter As Database2DataSetTableAdapters.Table1TableAdapter
    Friend WithEvents Table1BindingSource As BindingSource
    Friend WithEvents Database2DataSet As Database2DataSet
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TableAdapterManager As Database2DataSetTableAdapters.TableAdapterManager
    Friend WithEvents Timer1 As Timer
    Friend WithEvents panelSlidebar2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Table2BindingSource As BindingSource
    Friend WithEvents Table2TableAdapter As Database2DataSetTableAdapters.Table2TableAdapter
    Friend WithEvents Table2DataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents ItemQuantityTextBox As TextBox
    Friend WithEvents ItemNameComboBox As ComboBox
    Friend WithEvents ItemReserverNameTextBox As TextBox
    Friend WithEvents ContactNumTextBox As TextBox
    Friend WithEvents ItemDateReservedDateTimePicker As DateTimePicker
    Friend WithEvents ItemStartingTimeDateTimePicker As DateTimePicker
    Friend WithEvents ItemEndingTimeDateTimePicker As DateTimePicker
End Class
