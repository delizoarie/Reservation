﻿Public Class Form6
    Dim isHide2 As Boolean
    Dim pw2 As Integer
    Private Sub Table1BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Table1BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database2DataSet)

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database2DataSet.Table1' table. You can move, or remove it, as needed.
        Me.Table1TableAdapter.Fill(Me.Database2DataSet.Table1)

        pw2 = panelSlidebar2.Width
        isHide2 = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Table1TableAdapter.InsertQuery1(TextBox1.Text, TextBox2.Text, DateAddedDateTimePicker.Value)
        Me.Table1TableAdapter.Fill(Me.Database2DataSet.Table1)
        MessageBox.Show("bobo")
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If isHide2 Then
            panelSlidebar2.Width = panelSlidebar2.Width + 5

            If panelSlidebar2.Width >= 180 Then
                Timer1.Stop()
                isHide2 = False
                Refresh()
            End If

        Else
            panelSlidebar2.Width = panelSlidebar2.Width - 5

            If panelSlidebar2.Width <= 0 Then
                Timer1.Stop()
                isHide2 = True
                Refresh()


            End If
        End If
    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Timer1.Start()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form7.ShowDialog()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        MessageBox.Show("Are you sure you want to logout?", "LOGOUT", MessageBoxButtons.OKCancel)
        If DialogResult.OK Then
            Me.Hide()
            Form1.Show()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class