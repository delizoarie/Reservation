﻿Public Class Form5
    Dim isHide1 As Boolean
    Dim pw1 As Integer
    Shared start As DateTime
    Shared stop1 As DateTime
    Shared elapsed As TimeSpan
    Shared venue As String
    Shared RESERVEDby As String
    Shared nextReserve As TimeSpan
    Dim CountDown As Integer


    Private Sub TableBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.TableBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database2DataSet)
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database2DataSet.Table' table. You can move, or remove it, as needed.
        Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
        Date_ReservedDateTimePicker.Enabled = False
        pw1 = panelSlidebar1.Width
        isHide1 = True

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
        Form2.Show()
    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = DateTime.Now
        Dim startTime As DateTime
        Dim timeStart As String
        Dim timeEnd As String
        For i As Integer = 0 To Me.TableTableAdapter.CountRows()
            Try

                startTime = Me.TableDataGridView(7, i).Value
                venue = Me.TableDataGridView(1, i).Value.ToString
                nextReserve = startTime.Subtract(DateTime.Now)
                If venue = "Gymnasium" And Me.TableDataGridView(13, i).Value.ToString.Contains("Reserved") = True And startTime.ToString = Me.TableDataGridView(7, i).Value.ToString Then
                    GymnasiumLabel.Text = FontStyle.Bold
                    GymnasiumLabel.Text = getTimeString(nextReserve)
                End If

                If venue = "Covered Courts" And Me.TableDataGridView(13, i).Value.ToString.Contains("Reserved") = True And startTime.ToString = Me.TableDataGridView(7, i).Value.ToString Then
                    CoveredCourtsLabel.Text = FontStyle.Bold
                    CoveredCourtsLabel.Text = getTimeString(nextReserve)
                End If

                If venue = "Soccer Field" And Me.TableDataGridView(13, i).Value.ToString.Contains("Reserved") = True And startTime.ToString = Me.TableDataGridView(7, i).Value.ToString Then
                    SoccerFieldLabel.Text = FontStyle.Bold
                    SoccerFieldLabel.Text = getTimeString(nextReserve)
                End If

                timeStart = Me.TableDataGridView(7, i).Value.ToString
                timeEnd = Me.TableDataGridView(8, i).Value.ToString
                If timeStart.Contains(Label1.Text) And Me.TableDataGridView(13, i).Value.ToString = "Reserved" Then
                    MessageBox.Show("Reservation at " & Me.TableDataGridView(1, i).Value.ToString & " by " & Me.TableDataGridView(9, i).Value.ToString & " start now at " & Me.TableDataGridView(7, i).Value.ToString & " to " & Me.TableDataGridView(8, i).Value.ToString, "RESERVATION START", MessageBoxButtons.OK)
                    Me.TableTableAdapter.UpdateReservedState("Ongoing Reserve", Me.TableDataGridView(0, i).Value)
                    If DialogResult.OK Then
                        Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
                    End If
                    start = Me.TableDataGridView(7, i).Value
                        stop1 = Me.TableDataGridView(8, i).Value
                        venue = Me.TableDataGridView(1, i).Value.ToString
                        RESERVEDby = Me.TableDataGridView(9, i).Value.ToString
                        Timer3.Start()

                    End If

                    If timeEnd.Contains(Label1.Text) And Me.TableDataGridView(13, i).Value.ToString = "Ongoing Reserve" Then
                    MessageBox.Show("Reservation at " & Me.TableDataGridView(1, i).Value.ToString & " by " & Me.TableDataGridView(9, i).Value.ToString & " on " & Me.TableDataGridView(7, i).Value.ToString & " to " & Me.TableDataGridView(8, i).Value.ToString & "End", "RESERVATION END", MessageBoxButtons.OK)
                    Me.TableTableAdapter.UpdateReservedState("End Reservation", Me.TableDataGridView(0, i).Value)
                    If DialogResult.OK Then
                        Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)

                        If Me.TableDataGridView(13, i).Value.ToString = "End Reservation" And GymnasiumLabel IsNot "Gymnasium is free" = True Then

                            GymnasiumLabel.Text = "Gymnasium is free"
                        End If

                        If Me.TableDataGridView(13, i).Value.ToString = "End Reservation" And CoveredCourtsLabel IsNot "Covered Courts is free" = True Then

                            CoveredCourtsLabel.Text = "Covered Courts is free"
                        End If

                        If Me.TableDataGridView(13, i).Value.ToString = "End Reservation" And SoccerFieldLabel IsNot "Soccer Field is free" = True Then
                            SoccerFieldLabel.Text = "Soccer Field is free"
                        End If
                    End If

                End If

            Catch ex As Exception

            End Try
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure?", "Cancel Reservation", MessageBoxButtons.YesNo)
        Dim reserveNumcancel As Integer
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then
            reserveNumcancel = InputBox("Input ReserveNum")
            Me.TableTableAdapter.UpdateReservedState("Cancelled", reserveNumcancel)
            Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
        End If
    End Sub



    Public Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Dim result As DialogResult = MessageBox.Show("Are you sure?", "Edit Reservation", MessageBoxButtons.YesNo)
            Dim reserveNumedit As Integer
            Dim ChkBox1Val As String
            Dim ChkBox2Val As String

            If result = DialogResult.No Then
            ElseIf result = DialogResult.Yes Then
                reserveNumedit = InputBox("Input ReserveNum to edit")

                If CheckedListBox1.CheckedItems.Count > 0 Then
                    For i As Integer = 0 To CheckedListBox1.CheckedItems.Count - 1
                        If ChkBox1Val = "" Then
                            ChkBox1Val = CheckedListBox1.CheckedItems(i)
                        Else
                            ChkBox1Val += ", " + CheckedListBox1.CheckedItems(i)
                        End If
                    Next
                End If

                If CheckedListBox2.CheckedItems.Count > 0 Then
                    For i As Integer = 0 To CheckedListBox2.CheckedItems.Count - 1
                        If ChkBox2Val = "" Then
                            ChkBox2Val = CheckedListBox2.CheckedItems(i)
                        Else
                            ChkBox2Val += ", " + CheckedListBox2.CheckedItems(i)
                        End If
                    Next
                End If
                Dim count As Integer
                count = Me.TableTableAdapter.SeeConflict(Venue_NameComboBox.Text, Date_of_UseDateTimePicker.Value, Starting_TimeDateTimePicker.Value, Ending_TimeDateTimePicker.Value)
                If count = 0 Then
                    Me.TableTableAdapter.UpdateQuery(Venue_NameComboBox.Text, Contact_TextBox.Text, XU_ID_TextBox.Text, Date_ReservedDateTimePicker.Value,
                                      Date_of_UseDateTimePicker.Value, Estimated_No__of_ParticipantsTextBox.Text, Starting_TimeDateTimePicker.Value, Ending_TimeDateTimePicker.Value, OrganizerTextBox.Text,
                                      Reserved_byTextBox.Text, ChkBox1Val, ChkBox2Val, reserveNumedit)
                    Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
                Else
                    MsgBox("Time conflict with starting and ending time set. Please change accordingly.")
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("Please fill in everything / check at least 1 item in checkboxes")
        End Try
    End Sub



    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If isHide1 Then
            panelSlidebar1.Width = panelSlidebar1.Width + 5

            If panelSlidebar1.Width >= 180 Then
                Timer2.Stop()
                isHide1 = False
                Refresh()
            End If

        Else
            panelSlidebar1.Width = panelSlidebar1.Width - 5

            If panelSlidebar1.Width <= 0 Then
                Timer2.Stop()
                isHide1 = True
                Refresh()


            End If
        End If
    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Timer2.Start()
    End Sub
    Private Sub Venue_NameComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Venue_NameComboBox.SelectedIndexChanged

        If Venue_NameComboBox.Text.Contains("Gymnasium") = True Then
            CheckedListBox1.Items.Clear()
            CheckedListBox1.Items.Add("1st Floor Only")
            CheckedListBox1.Items.Add("1st Floor and 2nd floor")
            CheckedListBox1.Items.Add("Stage")
            CheckedListBox1.Items.Add("Dug-Out")
            CheckedListBox1.Items.Add("Bleachers")
            CheckedListBox1.Items.Add("Without Light")
            CheckedListBox1.Items.Add("With Light")
        End If

        If Venue_NameComboBox.Text.Contains("Covered Courts") = True Then
            CheckedListBox1.Items.Clear()
            CheckedListBox1.Items.Add("Half of the Field")
            CheckedListBox1.Items.Add("Whole Field")
            CheckedListBox1.Items.Add("Without Light")
            CheckedListBox1.Items.Add("With Light")
        End If

        If Venue_NameComboBox.Text.Contains("Soccer Field") = True Then
            CheckedListBox1.Items.Clear()
            CheckedListBox1.Items.Add("1 Court")
            CheckedListBox1.Items.Add("2 Courts")
            CheckedListBox1.Items.Add("Stage")
            CheckedListBox1.Items.Add("Green Room")
            CheckedListBox1.Items.Add("Without Light")
            CheckedListBox1.Items.Add("With Light")
        End If



    End Sub
    Private Sub TableDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles TableDataGridView.RowHeaderMouseClick
        Try
            Contact_TextBox.Text = TableDataGridView.SelectedRows.Item(1).ToString
            XU_ID_TextBox.Text = TableDataGridView.SelectedRows.Item(2).ToString
            Date_ReservedDateTimePicker.Value = TableDataGridView.SelectedRows.Item(3).ToString
            Date_of_UseDateTimePicker.Value = TableDataGridView.SelectedRows.Item(4).ToString
            Estimated_No__of_ParticipantsTextBox.Text = TableDataGridView.SelectedRows.Item(5).ToString
            Starting_TimeDateTimePicker.Value = TableDataGridView.SelectedRows.Item(6).ToString
            Ending_TimeDateTimePicker.Value = TableDataGridView.SelectedRows.Item(7).ToString
            OrganizerTextBox.Text = TableDataGridView.SelectedRows.Item(8).ToString
            Reserved_byTextBox.Text = TableDataGridView.SelectedRows.Item(9).ToString

        Catch ex As Exception
        End Try

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.Hide()
        Form6.Show()

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        elapsed = stop1.Subtract(DateTime.Now)
        If venue = "Gymnasium" Then
            GymnasiumLabel.Text = FontStyle.Bold
            GymnasiumLabel.Text = getTimeString(elapsed)
        End If

        If venue = "Covered Courts" Then
            CoveredCourtsLabel.Text = FontStyle.Bold
            CoveredCourtsLabel.Text = getTimeString(elapsed)
        End If

        If venue = "Soccer Field" Then
            SoccerFieldLabel.Text = FontStyle.Bold
            SoccerFieldLabel.Text = getTimeString(elapsed)
        End If


    End Sub

    Private Function getTimeString(ByVal elapsed As TimeSpan) As String

        Return (elapsed.Hours.ToString("00") + ":" + elapsed.Minutes.ToString("00") _
 + ":" + elapsed.Seconds.ToString("00"))

    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If ComboBox1.Text = "Venue Name" Then
            Me.TableTableAdapter.fillVenueName(Me.Database2DataSet.Table, TextBox1.Text)
        End If

        If ComboBox1.Text = "Date of Use" Then
            Me.TableTableAdapter.fillDateOfUse(Me.Database2DataSet.Table, TextBox1.Text)
        End If

        If ComboBox1.Text = "Date of Use" Then
            Me.TableTableAdapter.FillReservedState(Me.Database2DataSet.Table, TextBox1.Text)
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        MessageBox.Show("Are you sure you want to logout?", "LOGOUT", MessageBoxButtons.OKCancel)
        If DialogResult.OK Then
            Me.Hide()
            Form1.Show()
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        Form4.Show()
    End Sub
End Class