﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Venue_NameLabel As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Reserved_byLabel As System.Windows.Forms.Label
        Dim OrganizerLabel As System.Windows.Forms.Label
        Dim Ending_TimeLabel As System.Windows.Forms.Label
        Dim Starting_TimeLabel As System.Windows.Forms.Label
        Dim Estimated_No__of_ParticipantsLabel As System.Windows.Forms.Label
        Dim Date_of_UseLabel As System.Windows.Forms.Label
        Dim XU_ID_Label As System.Windows.Forms.Label
        Dim Contact_Label As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.panelSlidebar1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Venue_NameComboBox = New System.Windows.Forms.ComboBox()
        Me.TableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database2DataSet = New Court.Database2DataSet()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.Reserved_byTextBox = New System.Windows.Forms.TextBox()
        Me.OrganizerTextBox = New System.Windows.Forms.TextBox()
        Me.Ending_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Starting_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Estimated_No__of_ParticipantsTextBox = New System.Windows.Forms.TextBox()
        Me.Date_of_UseDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Date_ReservedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.XU_ID_TextBox = New System.Windows.Forms.TextBox()
        Me.Contact_TextBox = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TableDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.GymnasiumLabel = New System.Windows.Forms.Label()
        Me.CoveredCourtsLabel = New System.Windows.Forms.Label()
        Me.SoccerFieldLabel = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TableTableAdapter = New Court.Database2DataSetTableAdapters.TableTableAdapter()
        Me.TableAdapterManager = New Court.Database2DataSetTableAdapters.TableAdapterManager()
        Me.Database2DataSet1 = New Court.Database2DataSet()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.TableTableAdapter1 = New Court.Database1DataSetTableAdapters.TableTableAdapter()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Venue_NameLabel = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Reserved_byLabel = New System.Windows.Forms.Label()
        OrganizerLabel = New System.Windows.Forms.Label()
        Ending_TimeLabel = New System.Windows.Forms.Label()
        Starting_TimeLabel = New System.Windows.Forms.Label()
        Estimated_No__of_ParticipantsLabel = New System.Windows.Forms.Label()
        Date_of_UseLabel = New System.Windows.Forms.Label()
        XU_ID_Label = New System.Windows.Forms.Label()
        Contact_Label = New System.Windows.Forms.Label()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSlidebar1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TableDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database2DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Venue_NameLabel
        '
        Venue_NameLabel.AutoSize = True
        Venue_NameLabel.Location = New System.Drawing.Point(51, 35)
        Venue_NameLabel.Name = "Venue_NameLabel"
        Venue_NameLabel.Size = New System.Drawing.Size(97, 20)
        Venue_NameLabel.TabIndex = 129
        Venue_NameLabel.Text = "Venue Name:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(409, 268)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(199, 20)
        Label3.TabIndex = 126
        Label3.Text = "Manpower and Other Needs:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Location = New System.Drawing.Point(56, 268)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(86, 20)
        Label4.TabIndex = 125
        Label4.Text = "Facility Use:"
        '
        'Reserved_byLabel
        '
        Reserved_byLabel.AutoSize = True
        Reserved_byLabel.Location = New System.Drawing.Point(53, 214)
        Reserved_byLabel.Name = "Reserved_byLabel"
        Reserved_byLabel.Size = New System.Drawing.Size(92, 20)
        Reserved_byLabel.TabIndex = 123
        Reserved_byLabel.Text = "Reserved by:"
        '
        'OrganizerLabel
        '
        OrganizerLabel.AutoSize = True
        OrganizerLabel.Location = New System.Drawing.Point(70, 166)
        OrganizerLabel.Name = "OrganizerLabel"
        OrganizerLabel.Size = New System.Drawing.Size(77, 20)
        OrganizerLabel.TabIndex = 121
        OrganizerLabel.Text = "Organizer:"
        '
        'Ending_TimeLabel
        '
        Ending_TimeLabel.AutoSize = True
        Ending_TimeLabel.Location = New System.Drawing.Point(508, 213)
        Ending_TimeLabel.Name = "Ending_TimeLabel"
        Ending_TimeLabel.Size = New System.Drawing.Size(95, 20)
        Ending_TimeLabel.TabIndex = 119
        Ending_TimeLabel.Text = "Ending Time:"
        '
        'Starting_TimeLabel
        '
        Starting_TimeLabel.AutoSize = True
        Starting_TimeLabel.Location = New System.Drawing.Point(503, 165)
        Starting_TimeLabel.Name = "Starting_TimeLabel"
        Starting_TimeLabel.Size = New System.Drawing.Size(101, 20)
        Starting_TimeLabel.TabIndex = 116
        Starting_TimeLabel.Text = "Starting Time:"
        '
        'Estimated_No__of_ParticipantsLabel
        '
        Estimated_No__of_ParticipantsLabel.AutoSize = True
        Estimated_No__of_ParticipantsLabel.Location = New System.Drawing.Point(394, 122)
        Estimated_No__of_ParticipantsLabel.Name = "Estimated_No__of_ParticipantsLabel"
        Estimated_No__of_ParticipantsLabel.Size = New System.Drawing.Size(205, 20)
        Estimated_No__of_ParticipantsLabel.TabIndex = 115
        Estimated_No__of_ParticipantsLabel.Text = "Estimated No  of Participants:"
        '
        'Date_of_UseLabel
        '
        Date_of_UseLabel.AutoSize = True
        Date_of_UseLabel.Location = New System.Drawing.Point(512, 78)
        Date_of_UseLabel.Name = "Date_of_UseLabel"
        Date_of_UseLabel.Size = New System.Drawing.Size(90, 20)
        Date_of_UseLabel.TabIndex = 113
        Date_of_UseLabel.Text = "Date of Use:"
        '
        'XU_ID_Label
        '
        XU_ID_Label.AutoSize = True
        XU_ID_Label.Location = New System.Drawing.Point(89, 122)
        XU_ID_Label.Name = "XU_ID_Label"
        XU_ID_Label.Size = New System.Drawing.Size(59, 20)
        XU_ID_Label.TabIndex = 109
        XU_ID_Label.Text = "XU ID#:"
        '
        'Contact_Label
        '
        Contact_Label.AutoSize = True
        Contact_Label.Location = New System.Drawing.Point(77, 79)
        Contact_Label.Name = "Contact_Label"
        Contact_Label.Size = New System.Drawing.Size(72, 20)
        Contact_Label.TabIndex = 107
        Contact_Label.Text = "Contact#:"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 63)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1204, 11)
        Me.Panel2.TabIndex = 77
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1204, 63)
        Me.Panel3.TabIndex = 76
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(13, 9)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 10
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(1139, 11)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 9
        Me.PictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(491, 11)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(325, 41)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "VENUE RESERVATION"
        '
        'panelSlidebar1
        '
        Me.panelSlidebar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.panelSlidebar1.Controls.Add(Me.PictureBox1)
        Me.panelSlidebar1.Controls.Add(Me.Label6)
        Me.panelSlidebar1.Controls.Add(Me.Label5)
        Me.panelSlidebar1.Controls.Add(Me.PictureBox14)
        Me.panelSlidebar1.Controls.Add(Me.PictureBox5)
        Me.panelSlidebar1.Controls.Add(Me.PictureBox11)
        Me.panelSlidebar1.Controls.Add(Me.PictureBox10)
        Me.panelSlidebar1.Controls.Add(Me.PictureBox9)
        Me.panelSlidebar1.Controls.Add(Me.Button4)
        Me.panelSlidebar1.Controls.Add(Me.Button11)
        Me.panelSlidebar1.Controls.Add(Me.Button9)
        Me.panelSlidebar1.Controls.Add(Me.Button8)
        Me.panelSlidebar1.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelSlidebar1.Location = New System.Drawing.Point(0, 74)
        Me.panelSlidebar1.Name = "panelSlidebar1"
        Me.panelSlidebar1.Size = New System.Drawing.Size(224, 845)
        Me.panelSlidebar1.TabIndex = 78
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(88, 178)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(65, 63)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(46, 255)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 25)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "User Account"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(80, 295)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 25)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Label5"
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), System.Drawing.Image)
        Me.PictureBox14.Location = New System.Drawing.Point(18, 357)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox14.TabIndex = 3
        Me.PictureBox14.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(17, 796)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(20, 442)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 5
        Me.PictureBox11.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(18, 526)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(35, 34)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 6
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(25, 6)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(176, 136)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 7
        Me.PictureBox9.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button4.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(8, 348)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(208, 55)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "Venue"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button11.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.White
        Me.Button11.Location = New System.Drawing.Point(8, 786)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(208, 55)
        Me.Button11.TabIndex = 9
        Me.Button11.Text = " Log Out"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button9.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.White
        Me.Button9.Location = New System.Drawing.Point(8, 516)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(208, 55)
        Me.Button9.TabIndex = 10
        Me.Button9.Text = "       Reservation"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Button8.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(8, 432)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(208, 55)
        Me.Button8.TabIndex = 11
        Me.Button8.Text = "     Equipment"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Timer2
        '
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(718, 392)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(19, 29)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "l"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Venue_NameComboBox)
        Me.Panel1.Controls.Add(Venue_NameLabel)
        Me.Panel1.Controls.Add(Me.CheckedListBox2)
        Me.Panel1.Controls.Add(Me.CheckedListBox1)
        Me.Panel1.Controls.Add(Label3)
        Me.Panel1.Controls.Add(Label4)
        Me.Panel1.Controls.Add(Reserved_byLabel)
        Me.Panel1.Controls.Add(Me.Reserved_byTextBox)
        Me.Panel1.Controls.Add(OrganizerLabel)
        Me.Panel1.Controls.Add(Me.OrganizerTextBox)
        Me.Panel1.Controls.Add(Ending_TimeLabel)
        Me.Panel1.Controls.Add(Me.Ending_TimeDateTimePicker)
        Me.Panel1.Controls.Add(Starting_TimeLabel)
        Me.Panel1.Controls.Add(Me.Starting_TimeDateTimePicker)
        Me.Panel1.Controls.Add(Estimated_No__of_ParticipantsLabel)
        Me.Panel1.Controls.Add(Me.Estimated_No__of_ParticipantsTextBox)
        Me.Panel1.Controls.Add(Date_of_UseLabel)
        Me.Panel1.Controls.Add(Me.Date_of_UseDateTimePicker)
        Me.Panel1.Controls.Add(Me.Date_ReservedDateTimePicker)
        Me.Panel1.Controls.Add(XU_ID_Label)
        Me.Panel1.Controls.Add(Me.XU_ID_TextBox)
        Me.Panel1.Controls.Add(Contact_Label)
        Me.Panel1.Controls.Add(Me.Contact_TextBox)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Font = New System.Drawing.Font("Segoe UI Symbol", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(276, 431)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(867, 481)
        Me.Panel1.TabIndex = 4
        '
        'Venue_NameComboBox
        '
        Me.Venue_NameComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.Venue_NameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Venue Name", True))
        Me.Venue_NameComboBox.FormattingEnabled = True
        Me.Venue_NameComboBox.Items.AddRange(New Object() {"Gymnasium", "Covered Courts", "Soccer Field"})
        Me.Venue_NameComboBox.Location = New System.Drawing.Point(151, 32)
        Me.Venue_NameComboBox.Name = "Venue_NameComboBox"
        Me.Venue_NameComboBox.Size = New System.Drawing.Size(200, 28)
        Me.Venue_NameComboBox.TabIndex = 130
        '
        'TableBindingSource
        '
        Me.TableBindingSource.DataMember = "Table"
        Me.TableBindingSource.DataSource = Me.Database2DataSet
        '
        'Database2DataSet
        '
        Me.Database2DataSet.DataSetName = "Database2DataSet"
        Me.Database2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Items.AddRange(New Object() {"Security Guard", "Janitor", "Electrician", "Sound System", "Sound System Operator", "Tables", "Mono-blocks"})
        Me.CheckedListBox2.Location = New System.Drawing.Point(607, 268)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(200, 136)
        Me.CheckedListBox2.TabIndex = 128
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(151, 272)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(200, 123)
        Me.CheckedListBox1.TabIndex = 127
        '
        'Reserved_byTextBox
        '
        Me.Reserved_byTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Reserved_byTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Reserved by", True))
        Me.Reserved_byTextBox.Location = New System.Drawing.Point(151, 211)
        Me.Reserved_byTextBox.Name = "Reserved_byTextBox"
        Me.Reserved_byTextBox.Size = New System.Drawing.Size(200, 27)
        Me.Reserved_byTextBox.TabIndex = 124
        '
        'OrganizerTextBox
        '
        Me.OrganizerTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.OrganizerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Organizer", True))
        Me.OrganizerTextBox.Location = New System.Drawing.Point(151, 163)
        Me.OrganizerTextBox.Name = "OrganizerTextBox"
        Me.OrganizerTextBox.Size = New System.Drawing.Size(200, 27)
        Me.OrganizerTextBox.TabIndex = 122
        '
        'Ending_TimeDateTimePicker
        '
        Me.Ending_TimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.Ending_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Ending Time", True))
        Me.Ending_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Ending_TimeDateTimePicker.Location = New System.Drawing.Point(605, 209)
        Me.Ending_TimeDateTimePicker.Name = "Ending_TimeDateTimePicker"
        Me.Ending_TimeDateTimePicker.ShowUpDown = True
        Me.Ending_TimeDateTimePicker.Size = New System.Drawing.Size(200, 27)
        Me.Ending_TimeDateTimePicker.TabIndex = 120
        '
        'Starting_TimeDateTimePicker
        '
        Me.Starting_TimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.Starting_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Starting Time", True))
        Me.Starting_TimeDateTimePicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.Starting_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Starting_TimeDateTimePicker.Location = New System.Drawing.Point(605, 161)
        Me.Starting_TimeDateTimePicker.MinDate = New Date(2020, 2, 25, 0, 0, 0, 0)
        Me.Starting_TimeDateTimePicker.Name = "Starting_TimeDateTimePicker"
        Me.Starting_TimeDateTimePicker.ShowUpDown = True
        Me.Starting_TimeDateTimePicker.Size = New System.Drawing.Size(200, 27)
        Me.Starting_TimeDateTimePicker.TabIndex = 118
        '
        'Estimated_No__of_ParticipantsTextBox
        '
        Me.Estimated_No__of_ParticipantsTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Estimated_No__of_ParticipantsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Estimated No_ of Participants", True))
        Me.Estimated_No__of_ParticipantsTextBox.Location = New System.Drawing.Point(605, 117)
        Me.Estimated_No__of_ParticipantsTextBox.Name = "Estimated_No__of_ParticipantsTextBox"
        Me.Estimated_No__of_ParticipantsTextBox.Size = New System.Drawing.Size(200, 27)
        Me.Estimated_No__of_ParticipantsTextBox.TabIndex = 117
        '
        'Date_of_UseDateTimePicker
        '
        Me.Date_of_UseDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date of Use", True))
        Me.Date_of_UseDateTimePicker.Location = New System.Drawing.Point(605, 74)
        Me.Date_of_UseDateTimePicker.Name = "Date_of_UseDateTimePicker"
        Me.Date_of_UseDateTimePicker.Size = New System.Drawing.Size(200, 27)
        Me.Date_of_UseDateTimePicker.TabIndex = 114
        '
        'Date_ReservedDateTimePicker
        '
        Me.Date_ReservedDateTimePicker.CalendarMonthBackground = System.Drawing.Color.White
        Me.Date_ReservedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date Reserved", True))
        Me.Date_ReservedDateTimePicker.Location = New System.Drawing.Point(605, 28)
        Me.Date_ReservedDateTimePicker.Name = "Date_ReservedDateTimePicker"
        Me.Date_ReservedDateTimePicker.Size = New System.Drawing.Size(200, 27)
        Me.Date_ReservedDateTimePicker.TabIndex = 112
        '
        'XU_ID_TextBox
        '
        Me.XU_ID_TextBox.BackColor = System.Drawing.SystemColors.Window
        Me.XU_ID_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "XU ID#", True))
        Me.XU_ID_TextBox.Location = New System.Drawing.Point(151, 119)
        Me.XU_ID_TextBox.Name = "XU_ID_TextBox"
        Me.XU_ID_TextBox.Size = New System.Drawing.Size(200, 27)
        Me.XU_ID_TextBox.TabIndex = 110
        '
        'Contact_TextBox
        '
        Me.Contact_TextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Contact_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Contact#", True))
        Me.Contact_TextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Contact_TextBox.Location = New System.Drawing.Point(151, 76)
        Me.Contact_TextBox.Name = "Contact_TextBox"
        Me.Contact_TextBox.Size = New System.Drawing.Size(200, 27)
        Me.Contact_TextBox.TabIndex = 108
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(442, 427)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(173, 51)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Edit Reservation"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(626, 427)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(213, 51)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Cancel Reservation"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TableDataGridView
        '
        Me.TableDataGridView.AutoGenerateColumns = False
        Me.TableDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TableDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14})
        Me.TableDataGridView.DataSource = Me.TableBindingSource
        Me.TableDataGridView.Location = New System.Drawing.Point(276, 123)
        Me.TableDataGridView.Name = "TableDataGridView"
        Me.TableDataGridView.RowHeadersWidth = 51
        Me.TableDataGridView.RowTemplate.Height = 24
        Me.TableDataGridView.Size = New System.Drawing.Size(839, 220)
        Me.TableDataGridView.TabIndex = 78
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ReserveNum"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ReserveNum"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Venue Name"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Venue Name"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Contact#"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Contact#"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "XU ID#"
        Me.DataGridViewTextBoxColumn4.HeaderText = "XU ID#"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Date Reserved"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Date Reserved"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Date of Use"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Date of Use"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Estimated No_ of Participants"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Estimated No_ of Participants"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Starting Time"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Starting Time"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 125
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Ending Time"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Ending Time"
        Me.DataGridViewTextBoxColumn9.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 125
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Organizer"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Organizer"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.Width = 125
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "Reserved by"
        Me.DataGridViewTextBoxColumn11.HeaderText = "Reserved by"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 125
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "Facility Use"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Facility Use"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.Width = 125
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "Man Power"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Man Power"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Width = 125
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "Reserved State"
        Me.DataGridViewTextBoxColumn14.HeaderText = "Reserved State"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.Width = 125
        '
        'Timer3
        '
        '
        'GymnasiumLabel
        '
        Me.GymnasiumLabel.AutoSize = True
        Me.GymnasiumLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GymnasiumLabel.Location = New System.Drawing.Point(422, 355)
        Me.GymnasiumLabel.Name = "GymnasiumLabel"
        Me.GymnasiumLabel.Size = New System.Drawing.Size(167, 23)
        Me.GymnasiumLabel.TabIndex = 79
        Me.GymnasiumLabel.Text = "Gymnasium is free"
        '
        'CoveredCourtsLabel
        '
        Me.CoveredCourtsLabel.AutoSize = True
        Me.CoveredCourtsLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CoveredCourtsLabel.Location = New System.Drawing.Point(452, 398)
        Me.CoveredCourtsLabel.Name = "CoveredCourtsLabel"
        Me.CoveredCourtsLabel.Size = New System.Drawing.Size(200, 23)
        Me.CoveredCourtsLabel.TabIndex = 80
        Me.CoveredCourtsLabel.Text = "Covered Courts is free"
        '
        'SoccerFieldLabel
        '
        Me.SoccerFieldLabel.AutoSize = True
        Me.SoccerFieldLabel.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SoccerFieldLabel.Location = New System.Drawing.Point(865, 355)
        Me.SoccerFieldLabel.Name = "SoccerFieldLabel"
        Me.SoccerFieldLabel.Size = New System.Drawing.Size(167, 23)
        Me.SoccerFieldLabel.TabIndex = 81
        Me.SoccerFieldLabel.Text = "Soccer field is free"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(236, 86)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 25)
        Me.Label7.TabIndex = 82
        Me.Label7.Text = "Search:"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(322, 85)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(141, 28)
        Me.TextBox1.TabIndex = 83
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(517, 86)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 25)
        Me.Label8.TabIndex = 84
        Me.Label8.Text = "Filter by:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Venue Name", "Date Of Use", "Reserved State"})
        Me.ComboBox1.Location = New System.Drawing.Point(616, 85)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(163, 28)
        Me.ComboBox1.TabIndex = 85
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(803, 81)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(126, 36)
        Me.Button2.TabIndex = 86
        Me.Button2.Text = "Search"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TableTableAdapter
        '
        Me.TableTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Table1TableAdapter = Nothing
        Me.TableAdapterManager.Table2TableAdapter = Nothing
        Me.TableAdapterManager.TableTableAdapter = Me.TableTableAdapter
        Me.TableAdapterManager.UpdateOrder = Court.Database2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Database2DataSet1
        '
        Me.Database2DataSet1.DataSetName = "Database2DataSet"
        Me.Database2DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(935, 81)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(126, 36)
        Me.Button5.TabIndex = 87
        Me.Button5.Text = "Refresh"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'TableTableAdapter1
        '
        Me.TableTableAdapter1.ClearBeforeFill = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(718, 355)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(114, 23)
        Me.Label9.TabIndex = 90
        Me.Label9.Text = "Soccer field:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(285, 398)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(147, 23)
        Me.Label10.TabIndex = 89
        Me.Label10.Text = "Covered Courts:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Symbol", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(285, 355)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(120, 23)
        Me.Label11.TabIndex = 88
        Me.Label11.Text = "Gymnasium: "
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1204, 919)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.SoccerFieldLabel)
        Me.Controls.Add(Me.CoveredCourtsLabel)
        Me.Controls.Add(Me.GymnasiumLabel)
        Me.Controls.Add(Me.TableDataGridView)
        Me.Controls.Add(Me.panelSlidebar1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form5"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form5"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSlidebar1.ResumeLayout(False)
        Me.panelSlidebar1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TableDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database2DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Database2DataSet As Database2DataSet
    Friend WithEvents TableBindingSource As BindingSource
    Friend WithEvents TableTableAdapter As Database2DataSetTableAdapters.TableTableAdapter
    Friend WithEvents TableAdapterManager As Database2DataSetTableAdapters.TableAdapterManager
    Friend WithEvents Database2DataSet1 As Database2DataSet
    Friend WithEvents TableTableAdapter1 As Database1DataSetTableAdapters.TableTableAdapter
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents panelSlidebar1 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TableDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Public WithEvents Venue_NameComboBox As ComboBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Reserved_byTextBox As TextBox
    Friend WithEvents OrganizerTextBox As TextBox
    Friend WithEvents Ending_TimeDateTimePicker As DateTimePicker
    Friend WithEvents Starting_TimeDateTimePicker As DateTimePicker
    Friend WithEvents Estimated_No__of_ParticipantsTextBox As TextBox
    Friend WithEvents Date_of_UseDateTimePicker As DateTimePicker
    Friend WithEvents Date_ReservedDateTimePicker As DateTimePicker
    Friend WithEvents XU_ID_TextBox As TextBox
    Friend WithEvents Contact_TextBox As TextBox
    Friend WithEvents Timer3 As Timer
    Friend WithEvents GymnasiumLabel As Label
    Friend WithEvents CoveredCourtsLabel As Label
    Friend WithEvents SoccerFieldLabel As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
End Class
