﻿Public Class Form2

    Dim isHide As Boolean
    Dim pw As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form4.ShowDialog()


    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If isHide Then
            panelSlidebar.Width = panelSlidebar.Width + 5

            If panelSlidebar.Width >= 200 Then
                Timer1.Stop()
                isHide = False
                Refresh()
            End If

        Else
            panelSlidebar.Width = panelSlidebar.Width - 5

            If panelSlidebar.Width <= 0 Then
                Timer1.Stop()
                isHide = True
                Refresh()


            End If
        End If
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Timer1.Start()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Form1.Show()
        Me.Close()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Hide()
        Form5.ShowDialog()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        MessageBox.Show("Are you sure you want to logout?", "LOGOUT", MessageBoxButtons.OKCancel)
        If DialogResult.OK Then
            Me.Hide()
            Form1.Show()
        End If
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pw = panelSlidebar.Width
        isHide = True
        Timer1.Start()
        Timer2.Start()
        Label5.Text = "Welcome, " & Form1.UsernameTextBox.Text
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.Hide()
        Form6.ShowDialog()

    End Sub

    Private Function getTimeString(ByVal elapsed As TimeSpan) As String

        Return (elapsed.Hours.ToString("00") + ":" + elapsed.Minutes.ToString("00") _
 + ":" + elapsed.Seconds.ToString("00"))

    End Function

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Label3.Text = Form5.SoccerFieldLabel.Text
        Label10.Text = Form5.GymnasiumLabel.Text
        Label7.Text = Form5.CoveredCourtsLabel.Text

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class