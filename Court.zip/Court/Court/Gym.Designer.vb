﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Gym
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Contact_Label As System.Windows.Forms.Label
        Dim XU_ID_Label As System.Windows.Forms.Label
        Dim Date_ReservedLabel As System.Windows.Forms.Label
        Dim Date_of_UseLabel As System.Windows.Forms.Label
        Dim Estimated_No__of_ParticipantsLabel As System.Windows.Forms.Label
        Dim Starting_TimeLabel As System.Windows.Forms.Label
        Dim Ending_TimeLabel As System.Windows.Forms.Label
        Dim OrganizerLabel As System.Windows.Forms.Label
        Dim Reserved_byLabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Venue_NameLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Gym))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database2DataSet = New Database2DataSet()
        Me.Contact_TextBox = New System.Windows.Forms.TextBox()
        Me.XU_ID_TextBox = New System.Windows.Forms.TextBox()
        Me.Date_ReservedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Date_of_UseDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Estimated_No__of_ParticipantsTextBox = New System.Windows.Forms.TextBox()
        Me.Starting_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Ending_TimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.OrganizerTextBox = New System.Windows.Forms.TextBox()
        Me.Reserved_byTextBox = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.TableTableAdapter = New Database2DataSetTableAdapters.TableTableAdapter()
        Me.TableAdapterManager = New Database2DataSetTableAdapters.TableAdapterManager()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Venue_NameComboBox = New System.Windows.Forms.ComboBox()
        Contact_Label = New System.Windows.Forms.Label()
        XU_ID_Label = New System.Windows.Forms.Label()
        Date_ReservedLabel = New System.Windows.Forms.Label()
        Date_of_UseLabel = New System.Windows.Forms.Label()
        Estimated_No__of_ParticipantsLabel = New System.Windows.Forms.Label()
        Starting_TimeLabel = New System.Windows.Forms.Label()
        Ending_TimeLabel = New System.Windows.Forms.Label()
        OrganizerLabel = New System.Windows.Forms.Label()
        Reserved_byLabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Venue_NameLabel = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Contact_Label
        '
        Contact_Label.AutoSize = True
        Contact_Label.Location = New System.Drawing.Point(58, 182)
        Contact_Label.Name = "Contact_Label"
        Contact_Label.Size = New System.Drawing.Size(68, 17)
        Contact_Label.TabIndex = 4
        Contact_Label.Text = "Contact#:"
        '
        'XU_ID_Label
        '
        XU_ID_Label.AutoSize = True
        XU_ID_Label.Location = New System.Drawing.Point(70, 225)
        XU_ID_Label.Name = "XU_ID_Label"
        XU_ID_Label.Size = New System.Drawing.Size(56, 17)
        XU_ID_Label.TabIndex = 6
        XU_ID_Label.Text = "XU ID#:"
        '
        'Date_ReservedLabel
        '
        Date_ReservedLabel.AutoSize = True
        Date_ReservedLabel.Location = New System.Drawing.Point(473, 135)
        Date_ReservedLabel.Name = "Date_ReservedLabel"
        Date_ReservedLabel.Size = New System.Drawing.Size(107, 17)
        Date_ReservedLabel.TabIndex = 8
        Date_ReservedLabel.Text = "Date Reserved:"
        '
        'Date_of_UseLabel
        '
        Date_of_UseLabel.AutoSize = True
        Date_of_UseLabel.Location = New System.Drawing.Point(493, 181)
        Date_of_UseLabel.Name = "Date_of_UseLabel"
        Date_of_UseLabel.Size = New System.Drawing.Size(87, 17)
        Date_of_UseLabel.TabIndex = 10
        Date_of_UseLabel.Text = "Date of Use:"
        '
        'Estimated_No__of_ParticipantsLabel
        '
        Estimated_No__of_ParticipantsLabel.AutoSize = True
        Estimated_No__of_ParticipantsLabel.Location = New System.Drawing.Point(386, 223)
        Estimated_No__of_ParticipantsLabel.Name = "Estimated_No__of_ParticipantsLabel"
        Estimated_No__of_ParticipantsLabel.Size = New System.Drawing.Size(194, 17)
        Estimated_No__of_ParticipantsLabel.TabIndex = 12
        Estimated_No__of_ParticipantsLabel.Text = "Estimated No  of Participants:"
        '
        'Starting_TimeLabel
        '
        Starting_TimeLabel.AutoSize = True
        Starting_TimeLabel.Location = New System.Drawing.Point(484, 268)
        Starting_TimeLabel.Name = "Starting_TimeLabel"
        Starting_TimeLabel.Size = New System.Drawing.Size(96, 17)
        Starting_TimeLabel.TabIndex = 13
        Starting_TimeLabel.Text = "Starting Time:"
        '
        'Ending_TimeLabel
        '
        Ending_TimeLabel.AutoSize = True
        Ending_TimeLabel.Location = New System.Drawing.Point(489, 316)
        Ending_TimeLabel.Name = "Ending_TimeLabel"
        Ending_TimeLabel.Size = New System.Drawing.Size(91, 17)
        Ending_TimeLabel.TabIndex = 15
        Ending_TimeLabel.Text = "Ending Time:"
        '
        'OrganizerLabel
        '
        OrganizerLabel.AutoSize = True
        OrganizerLabel.Location = New System.Drawing.Point(51, 269)
        OrganizerLabel.Name = "OrganizerLabel"
        OrganizerLabel.Size = New System.Drawing.Size(75, 17)
        OrganizerLabel.TabIndex = 17
        OrganizerLabel.Text = "Organizer:"
        '
        'Reserved_byLabel
        '
        Reserved_byLabel.AutoSize = True
        Reserved_byLabel.Location = New System.Drawing.Point(34, 317)
        Reserved_byLabel.Name = "Reserved_byLabel"
        Reserved_byLabel.Size = New System.Drawing.Size(92, 17)
        Reserved_byLabel.TabIndex = 19
        Reserved_byLabel.Text = "Reserved by:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(37, 371)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(84, 17)
        Label2.TabIndex = 40
        Label2.Text = "Facility Use:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(390, 371)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(190, 17)
        Label3.TabIndex = 40
        Label3.Text = "Manpower and Other Needs:"
        '
        'Venue_NameLabel
        '
        Venue_NameLabel.AutoSize = True
        Venue_NameLabel.Location = New System.Drawing.Point(32, 138)
        Venue_NameLabel.Name = "Venue_NameLabel"
        Venue_NameLabel.Size = New System.Drawing.Size(94, 17)
        Venue_NameLabel.TabIndex = 76
        Venue_NameLabel.Text = "Venue Name:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(19, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(845, 63)
        Me.Panel1.TabIndex = 1
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(788, 9)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(45, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 78
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(267, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(325, 41)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "VENUE RESERVATION"
        '
        'TableBindingSource
        '
        Me.TableBindingSource.DataMember = "Table"
        Me.TableBindingSource.DataSource = Me.Database2DataSet
        '
        'Database2DataSet
        '
        Me.Database2DataSet.DataSetName = "Database2DataSet"
        Me.Database2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Contact_TextBox
        '
        Me.Contact_TextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Contact_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Contact#", True))
        Me.Contact_TextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Contact_TextBox.Location = New System.Drawing.Point(132, 179)
        Me.Contact_TextBox.Name = "Contact_TextBox"
        Me.Contact_TextBox.Size = New System.Drawing.Size(200, 27)
        Me.Contact_TextBox.TabIndex = 5
        '
        'XU_ID_TextBox
        '
        Me.XU_ID_TextBox.BackColor = System.Drawing.SystemColors.Window
        Me.XU_ID_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "XU ID#", True))
        Me.XU_ID_TextBox.Location = New System.Drawing.Point(132, 222)
        Me.XU_ID_TextBox.Name = "XU_ID_TextBox"
        Me.XU_ID_TextBox.Size = New System.Drawing.Size(200, 22)
        Me.XU_ID_TextBox.TabIndex = 7
        '
        'Date_ReservedDateTimePicker
        '
        Me.Date_ReservedDateTimePicker.CalendarMonthBackground = System.Drawing.Color.White
        Me.Date_ReservedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date Reserved", True))
        Me.Date_ReservedDateTimePicker.Location = New System.Drawing.Point(586, 131)
        Me.Date_ReservedDateTimePicker.Name = "Date_ReservedDateTimePicker"
        Me.Date_ReservedDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Date_ReservedDateTimePicker.TabIndex = 9
        '
        'Date_of_UseDateTimePicker
        '
        Me.Date_of_UseDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Date of Use", True))
        Me.Date_of_UseDateTimePicker.Location = New System.Drawing.Point(586, 177)
        Me.Date_of_UseDateTimePicker.Name = "Date_of_UseDateTimePicker"
        Me.Date_of_UseDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Date_of_UseDateTimePicker.TabIndex = 11
        '
        'Estimated_No__of_ParticipantsTextBox
        '
        Me.Estimated_No__of_ParticipantsTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Estimated_No__of_ParticipantsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Estimated No_ of Participants", True))
        Me.Estimated_No__of_ParticipantsTextBox.Location = New System.Drawing.Point(586, 220)
        Me.Estimated_No__of_ParticipantsTextBox.Name = "Estimated_No__of_ParticipantsTextBox"
        Me.Estimated_No__of_ParticipantsTextBox.Size = New System.Drawing.Size(200, 22)
        Me.Estimated_No__of_ParticipantsTextBox.TabIndex = 13
        '
        'Starting_TimeDateTimePicker
        '
        Me.Starting_TimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.Starting_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Starting Time", True))
        Me.Starting_TimeDateTimePicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.Starting_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Starting_TimeDateTimePicker.Location = New System.Drawing.Point(586, 264)
        Me.Starting_TimeDateTimePicker.MinDate = New Date(2020, 2, 25, 0, 0, 0, 0)
        Me.Starting_TimeDateTimePicker.Name = "Starting_TimeDateTimePicker"
        Me.Starting_TimeDateTimePicker.ShowUpDown = True
        Me.Starting_TimeDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Starting_TimeDateTimePicker.TabIndex = 14
        '
        'Ending_TimeDateTimePicker
        '
        Me.Ending_TimeDateTimePicker.CustomFormat = "hh:mm:ss tt"
        Me.Ending_TimeDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TableBindingSource, "Ending Time", True))
        Me.Ending_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Ending_TimeDateTimePicker.Location = New System.Drawing.Point(586, 312)
        Me.Ending_TimeDateTimePicker.Name = "Ending_TimeDateTimePicker"
        Me.Ending_TimeDateTimePicker.ShowUpDown = True
        Me.Ending_TimeDateTimePicker.Size = New System.Drawing.Size(200, 22)
        Me.Ending_TimeDateTimePicker.TabIndex = 16
        '
        'OrganizerTextBox
        '
        Me.OrganizerTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.OrganizerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Organizer", True))
        Me.OrganizerTextBox.Location = New System.Drawing.Point(132, 266)
        Me.OrganizerTextBox.Name = "OrganizerTextBox"
        Me.OrganizerTextBox.Size = New System.Drawing.Size(200, 22)
        Me.OrganizerTextBox.TabIndex = 18
        '
        'Reserved_byTextBox
        '
        Me.Reserved_byTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.Reserved_byTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Reserved by", True))
        Me.Reserved_byTextBox.Location = New System.Drawing.Point(132, 314)
        Me.Reserved_byTextBox.Name = "Reserved_byTextBox"
        Me.Reserved_byTextBox.Size = New System.Drawing.Size(200, 22)
        Me.Reserved_byTextBox.TabIndex = 20
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(546, 566)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(117, 36)
        Me.Button2.TabIndex = 38
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(669, 566)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(117, 36)
        Me.Button1.TabIndex = 39
        Me.Button1.Text = "Reserved"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(132, 375)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(200, 123)
        Me.CheckedListBox1.TabIndex = 44
        '
        'TableTableAdapter
        '
        Me.TableTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Table1TableAdapter = Nothing
        Me.TableAdapterManager.TableTableAdapter = Me.TableTableAdapter
        Me.TableAdapterManager.UpdateOrder = Database2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Items.AddRange(New Object() {"Security Guard", "Janitor", "Electrician", "Sound System", "Sound System Operator", "Tables", "Mono-blocks"})
        Me.CheckedListBox2.Location = New System.Drawing.Point(588, 371)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(200, 123)
        Me.CheckedListBox2.TabIndex = 45
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(40, 566)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(117, 36)
        Me.Button3.TabIndex = 46
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(163, 566)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(117, 36)
        Me.Button4.TabIndex = 46
        Me.Button4.Text = "View"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Venue_NameComboBox
        '
        Me.Venue_NameComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.Venue_NameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TableBindingSource, "Venue Name", True))
        Me.Venue_NameComboBox.FormattingEnabled = True
        Me.Venue_NameComboBox.Items.AddRange(New Object() {"Gymnasium", "Covered Courts", "Soccer Field"})
        Me.Venue_NameComboBox.Location = New System.Drawing.Point(132, 135)
        Me.Venue_NameComboBox.Name = "Venue_NameComboBox"
        Me.Venue_NameComboBox.Size = New System.Drawing.Size(200, 24)
        Me.Venue_NameComboBox.TabIndex = 77
        '
        'Gym
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Venue_NameLabel)
        Me.Controls.Add(Me.Venue_NameComboBox)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.CheckedListBox2)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Reserved_byLabel)
        Me.Controls.Add(Me.Reserved_byTextBox)
        Me.Controls.Add(OrganizerLabel)
        Me.Controls.Add(Me.OrganizerTextBox)
        Me.Controls.Add(Ending_TimeLabel)
        Me.Controls.Add(Me.Ending_TimeDateTimePicker)
        Me.Controls.Add(Starting_TimeLabel)
        Me.Controls.Add(Me.Starting_TimeDateTimePicker)
        Me.Controls.Add(Estimated_No__of_ParticipantsLabel)
        Me.Controls.Add(Me.Estimated_No__of_ParticipantsTextBox)
        Me.Controls.Add(Date_of_UseLabel)
        Me.Controls.Add(Me.Date_of_UseDateTimePicker)
        Me.Controls.Add(Date_ReservedLabel)
        Me.Controls.Add(Me.Date_ReservedDateTimePicker)
        Me.Controls.Add(XU_ID_Label)
        Me.Controls.Add(Me.XU_ID_TextBox)
        Me.Controls.Add(Contact_Label)
        Me.Controls.Add(Me.Contact_TextBox)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Gym"
        Me.Size = New System.Drawing.Size(845, 623)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database2DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Database2DataSet As Database2DataSet
    Friend WithEvents TableBindingSource As BindingSource
    Friend WithEvents TableTableAdapter As Database2DataSetTableAdapters.TableTableAdapter
    Friend WithEvents TableAdapterManager As Database2DataSetTableAdapters.TableAdapterManager
    Friend WithEvents Contact_TextBox As TextBox
    Friend WithEvents XU_ID_TextBox As TextBox
    Friend WithEvents Date_ReservedDateTimePicker As DateTimePicker
    Friend WithEvents Date_of_UseDateTimePicker As DateTimePicker
    Friend WithEvents Estimated_No__of_ParticipantsTextBox As TextBox
    Friend WithEvents Starting_TimeDateTimePicker As DateTimePicker
    Friend WithEvents OrganizerTextBox As TextBox
    Friend WithEvents Reserved_byTextBox As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Ending_TimeDateTimePicker As DateTimePicker
    Friend WithEvents PictureBox2 As PictureBox
    Public WithEvents Venue_NameComboBox As ComboBox
End Class
