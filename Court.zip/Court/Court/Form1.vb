﻿Public Class Form1
    Private Sub TableBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        'Me.Validate()
        'Me.TableBindingSource.EndEdit()
        'Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.Table' table. You can move, or remove it, as needed.
        'Me.TableTableAdapter.Fill(Me.Database1DataSet.Table)

    End Sub

    Private Sub UsernameTextBox_TextChanged(sender As Object, e As EventArgs) Handles UsernameTextBox.GotFocus
        UsernameTextBox.Text = ""
        UsernameTextBox.ForeColor = Color.Black
    End Sub

    Private Sub UsernameTextBox_LostFocus(sender As Object, e As EventArgs) Handles UsernameTextBox.LostFocus
        ' UsernameTextBox.Text = "Username"
        ' UsernameTextBox.ForeColor = Color.Silver
    End Sub

    Private Sub PasswordTextBox_TextChanged(sender As Object, e As EventArgs) Handles PasswordTextBox.GotFocus
        PasswordTextBox.Text = ""
        PasswordTextBox.ForeColor = Color.Black
    End Sub



    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Form3.ShowDialog()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim count As Integer

        count = TableTableAdapter.SelectQuery(UsernameTextBox.Text, PasswordTextBox.Text)
        If count > 0 Then
            MsgBox("Login Successfully")
            Form2.Show()
            Me.Hide()
        Else
            MsgBox("Incorrect Username Or Password")
        End If
    End Sub

    Private Sub PictureBox3_Click_1(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Close()
    End Sub

End Class
