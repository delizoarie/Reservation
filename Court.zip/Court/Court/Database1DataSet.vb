﻿Partial Class Database1DataSet
End Class

Namespace Database1DataSetTableAdapters
    Partial Public Class TableTableAdapter
    End Class
End Namespace
