﻿Partial Class Database2DataSet
End Class

Namespace Database2DataSetTableAdapters

    Partial Public Class TableTableAdapter
    End Class
End Namespace
