﻿Public Class Gym
    Private Sub TableBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.TableBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database2DataSet)

    End Sub

    Private Sub Contact_Label_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ChkBox1Val As String
        Dim ChkBox2Val As String
        If CheckedListBox1.CheckedItems.Count > 0 Then
            For i As Integer = 0 To CheckedListBox1.CheckedItems.Count - 1
                If ChkBox1Val = "" Then
                    ChkBox1Val = CheckedListBox1.CheckedItems(i)
                Else
                    ChkBox1Val += ", " + CheckedListBox1.CheckedItems(i)
                End If
            Next
        End If

        If CheckedListBox2.CheckedItems.Count > 0 Then
            For i As Integer = 0 To CheckedListBox2.CheckedItems.Count - 1
                If ChkBox2Val = "" Then
                    ChkBox2Val = CheckedListBox2.CheckedItems(i)
                Else
                    ChkBox2Val += ", " + CheckedListBox2.CheckedItems(i)
                End If
            Next
        End If

        Me.TableTableAdapter.InsertQuery(NameTextBox.Text, Contact_TextBox.Text, XU_ID_TextBox.Text, Date_ReservedDateTimePicker.Value,
                                      Date_of_UseDateTimePicker.Value, Estimated_No__of_ParticipantsTextBox.Text, Starting_TimeDateTimePicker.Value, Ending_TimeDateTimePicker.Value, OrganizerTextBox.Text,
                                      Reserved_byTextBox.Text, ChkBox1Val, ChkBox2Val)
        Me.TableTableAdapter.Fill(Me.Database2DataSet.Table)
        Ending_TimeDateTimePicker.Text = ""
        NameTextBox.Text = ""
        Contact_TextBox.Text = ""
        XU_ID_TextBox.Text = ""
        OrganizerTextBox.Text = ""
        Reserved_byTextBox.Text = ""
        Estimated_No__of_ParticipantsTextBox.Text = ""
        Date_ReservedDateTimePicker.Text = ""
        Date_of_UseDateTimePicker.Text = ""
        Starting_TimeDateTimePicker.Text = ""
        Ending_TimeDateTimePicker.Text = ""
        MessageBox.Show("Reserved")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("Cancel Reservation")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click, Button4.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class
